cockpit.locale({
 "": {
  "plural-forms": (n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5,
  "language": "ar",
  "language-direction": "rtl"
 },
 "Diagnostic reports": [
  null,
  "تقارير التشخيص"
 ],
 "Kernel dump": [
  null,
  "عطب نواة النظام"
 ],
 "Managing VLANs": [
  null,
  "إدارة الشبكات المحلية الافتراضية (VLANs)"
 ],
 "Managing firewall": [
  null,
  "إدارة الجدار الناري"
 ],
 "Managing networking bonds": [
  null,
  "إدارة الوصلات الشبكية المجمَّعة"
 ],
 "Managing networking bridges": [
  null,
  "إدارة جسور الشبكات"
 ],
 "Managing networking teams": [
  null,
  "إدارة فرق الشبكات"
 ],
 "Networking": [
  null,
  "التشبيك"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "الخدمات"
 ],
 "Storage": [
  null,
  "التخزين"
 ],
 "bond": [
  null,
  "رابط شبكي"
 ],
 "bridge": [
  null,
  "جسر"
 ],
 "firewall": [
  null,
  "الجِدار النّاري"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "الواجهة"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "الشَبكة"
 ],
 "port": [
  null,
  "منفذ"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "فريق"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "منطقة"
 ]
});
