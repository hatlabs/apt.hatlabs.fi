cockpit.locale({
 "": {
  "plural-forms": (n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3)),
  "language": "he",
  "language-direction": "rtl"
 },
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "Kernel dump": [
  null,
  "היטל ליבה"
 ],
 "Managing VLANs": [
  null,
  "ניהול VLANים"
 ],
 "Managing firewall": [
  null,
  "ניהול חומת אש"
 ],
 "Managing networking bonds": [
  null,
  "ניהול מאגדי רשת"
 ],
 "Managing networking bridges": [
  null,
  "ניהול גישורי רשת"
 ],
 "Managing networking teams": [
  null,
  "ניהול ציוותי רשת"
 ],
 "Networking": [
  null,
  "תקשורת"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "שירותים"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "bond": [
  null,
  "מאגד"
 ],
 "bridge": [
  null,
  "גשר"
 ],
 "firewall": [
  null,
  "חומת אש"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "מנשק"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "רשת"
 ],
 "port": [
  null,
  "פתחה"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "ציוות"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "אזור"
 ]
});
