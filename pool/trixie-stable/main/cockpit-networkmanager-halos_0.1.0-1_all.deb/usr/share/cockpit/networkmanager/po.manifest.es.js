cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Informes de diagnóstico"
 ],
 "Kernel dump": [
  null,
  "Volcado del kernel"
 ],
 "Managing VLANs": [
  null,
  "Gestión de VLANs"
 ],
 "Managing firewall": [
  null,
  "Gestión del cortafuegos"
 ],
 "Managing networking bonds": [
  null,
  "Gestión de agregaciones de enlaces de red"
 ],
 "Managing networking bridges": [
  null,
  "Gestión de puentes de red"
 ],
 "Managing networking teams": [
  null,
  "Gestión de agregaciones de interfaces de red"
 ],
 "Networking": [
  null,
  "Redes"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Servicios"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "bond": [
  null,
  "agregación de enlaces"
 ],
 "bridge": [
  null,
  "puente"
 ],
 "firewall": [
  null,
  "cortafuegos"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "interfaz"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "red"
 ],
 "port": [
  null,
  "puerto"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "equipo"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "zona"
 ]
});
