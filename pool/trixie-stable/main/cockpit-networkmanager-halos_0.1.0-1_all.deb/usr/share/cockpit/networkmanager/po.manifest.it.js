cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Managing VLANs": [
  null,
  "Gestione VLAN"
 ],
 "Managing firewall": [
  null,
  "Gestione del firewall"
 ],
 "Managing networking bonds": [
  null,
  "Gestendo bond di rete"
 ],
 "Managing networking bridges": [
  null,
  "Gestendo ponti della rete"
 ],
 "Managing networking teams": [
  null,
  "Gestendo team della rete"
 ],
 "Networking": [
  null,
  "Rete"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Servizi"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "bond": [
  null,
  "bond"
 ],
 "bridge": [
  null,
  "bridge"
 ],
 "firewall": [
  null,
  "firewall"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "interfaccia"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "rete"
 ],
 "port": [
  null,
  "porta"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "team"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "zona"
 ]
});
