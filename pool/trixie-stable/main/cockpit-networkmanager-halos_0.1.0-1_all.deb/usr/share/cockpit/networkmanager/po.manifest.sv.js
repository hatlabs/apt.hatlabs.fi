cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "Managing VLANs": [
  null,
  "Hantera VLAN"
 ],
 "Managing firewall": [
  null,
  "Hantera brandvägg"
 ],
 "Managing networking bonds": [
  null,
  "Hantera nätverksbindningar"
 ],
 "Managing networking bridges": [
  null,
  "Hantera nätverksbryggor"
 ],
 "Managing networking teams": [
  null,
  "Hantera nätverksteam"
 ],
 "Networking": [
  null,
  "Nätverk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Tjänster"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "bond": [
  null,
  "bindning"
 ],
 "bridge": [
  null,
  "brygga"
 ],
 "firewall": [
  null,
  "brandvägg"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "gränssnitt"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "nätverk"
 ],
 "port": [
  null,
  "port"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "team"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "zon"
 ]
});
