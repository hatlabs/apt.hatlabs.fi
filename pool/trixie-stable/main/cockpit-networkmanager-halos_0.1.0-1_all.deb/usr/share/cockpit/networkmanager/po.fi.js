cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 Git"
 ],
 "$0 active zone": [
  null,
  "$0 aktiivinen vyöhyke",
  "$0 aktiivista vyöhykettä"
 ],
 "$0 day": [
  null,
  "$0 päivä",
  "$0 päivää"
 ],
 "$0 exited with code $1": [
  null,
  "$0 poistui koodilla $1"
 ],
 "$0 failed": [
  null,
  "$0 epäonnistui"
 ],
 "$0 hour": [
  null,
  "$0 tunti",
  "$0 tuntia"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ei ole saatavilla mistään ohjelmistovarastosta."
 ],
 "$0 key changed": [
  null,
  "$0 avain muuttunut"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 tapettu signaalilla $1"
 ],
 "$0 minute": [
  null,
  "$0 minuutti",
  "$0 minuuttia"
 ],
 "$0 month": [
  null,
  "$0 kuukausi",
  "$0 kuukautta"
 ],
 "$0 week": [
  null,
  "$0 viikko",
  "$0 viikkoa"
 ],
 "$0 will be installed.": [
  null,
  "$0 asennetaan."
 ],
 "$0 year": [
  null,
  "$0 vuosi",
  "$0 vuotta"
 ],
 "$0 zone": [
  null,
  "$0 -vyöhyke"
 ],
 "1 day": [
  null,
  "1 päivä"
 ],
 "1 hour": [
  null,
  "1 tunti"
 ],
 "1 minute": [
  null,
  "1 minuutti"
 ],
 "1 week": [
  null,
  "1 viikko"
 ],
 "20 minutes": [
  null,
  "20 minuuttia"
 ],
 "40 minutes": [
  null,
  "40 minuuttia"
 ],
 "5 minutes": [
  null,
  "5 minuuttia"
 ],
 "6 hours": [
  null,
  "6 tuntia"
 ],
 "60 minutes": [
  null,
  "60 minuuttia"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Yhteensopivaa versiota Cockpitistä ei ole asennettu kohteessa $0."
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Verkkosidos yhdistää useita verkkoliitäntöjä yhdeksi loogiseksi liitännäksi, jolla on korkeampi suorituskyky tai redundanssi."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Uusi SSH-avain nimellä $0 luodaan käyttäjälle $1 koneella $2 ja se lisätään käyttäjän $3 tiedostoon $4 koneella $5."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "ARP-monitorointi"
 ],
 "ARP ping": [
  null,
  "ARP:n ping"
 ],
 "Absent": [
  null,
  "Poissa"
 ],
 "Acceptable password": [
  null,
  "Hyväksyttävä salasana"
 ],
 "Actions": [
  null,
  "Toimet"
 ],
 "Active": [
  null,
  "Aktiivinen"
 ],
 "Active backup": [
  null,
  "Aktiivinen varmennus"
 ],
 "Adaptive load balancing": [
  null,
  "Mukautuva kuormantasaus"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Mukautuva lähtevän kuorman tasaus"
 ],
 "Add": [
  null,
  "Lisää"
 ],
 "Add $0": [
  null,
  "Lisää $0"
 ],
 "Add DNS server": [
  null,
  "Lisää DNS-palvelin"
 ],
 "Add VLAN": [
  null,
  "Lisää VLAN"
 ],
 "Add VPN": [
  null,
  "Lisää VPN"
 ],
 "Add WireGuard VPN": [
  null,
  "Lisää WireGuard VPN"
 ],
 "Add a new zone": [
  null,
  "Lisää uusi vyöhyke"
 ],
 "Add address": [
  null,
  "Lisää osoite"
 ],
 "Add bond": [
  null,
  "Lisää sidos"
 ],
 "Add bridge": [
  null,
  "Lisää silta"
 ],
 "Add member": [
  null,
  "Lisää jäsen"
 ],
 "Add new zone": [
  null,
  "Lisää uusi vyöhyke"
 ],
 "Add peer": [
  null,
  "Lisää vertainen"
 ],
 "Add ports": [
  null,
  "Lisää portit"
 ],
 "Add ports to $0 zone": [
  null,
  "Lisää portteja vyöhykkeeseen $0"
 ],
 "Add route": [
  null,
  "Lisää reitti"
 ],
 "Add search domain": [
  null,
  "Lisää hakutoimialue"
 ],
 "Add services": [
  null,
  "Lisää palveluja"
 ],
 "Add services to $0 zone": [
  null,
  "Lisää palveluja vyöhykkeeseen $0"
 ],
 "Add services to zone $0": [
  null,
  "Lisää palveluja vyöhykkeeseen $0"
 ],
 "Add team": [
  null,
  "Lisää joukkue"
 ],
 "Add zone": [
  null,
  "Lisää vyöhyke"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0:n lisääminen katkaisee yhteyden palvelimeen, jolloin hallintakäyttöliittymä ei ole saatavilla."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Mukautettujen porttien lisääminen lataa firewalld:n uudelleen. Uudelleenlataus johtaa kaikkien vain-ajonaikaisen kokoonpanon menetykseen!"
 ],
 "Additional DNS $val": [
  null,
  "Ylimääräinen DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Lisä DNS-hakutoimialueita $val"
 ],
 "Additional address $val": [
  null,
  "Ylimääräinen osoite $val"
 ],
 "Additional packages:": [
  null,
  "Ylimääräiset paketit:"
 ],
 "Additional ports": [
  null,
  "Ylimääräiset portit"
 ],
 "Address": [
  null,
  "Osoite"
 ],
 "Address $val": [
  null,
  "Osoite $val"
 ],
 "Addresses": [
  null,
  "Osoitteet"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Osoitteet eivät ole oikein muotoiltuja"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Hallinta Cockpit-verkkokonsolilla"
 ],
 "Advanced TCA": [
  null,
  "Edistynyt TCA"
 ],
 "All-in-one": [
  null,
  "Kaikki yhdessä"
 ],
 "Allowed IPs": [
  null,
  "Sallitut IP-osoitteet"
 ],
 "Allowed addresses": [
  null,
  "Sallitut osoitteet"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible-roolien dokumentaatio"
 ],
 "Authenticating": [
  null,
  "Tunnistaudutaan"
 ],
 "Authentication": [
  null,
  "Tunnistautuminen"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Todennus vaaditaan etuoikeutettujen tehtävien suorittamiseen Cockpit Web Console:ssa"
 ],
 "Authorize SSH key": [
  null,
  "Valtuuta SSH-avain"
 ],
 "Automatic": [
  null,
  "Automaattinen"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automaattinen (vain DHCP)"
 ],
 "Automatically using NTP": [
  null,
  "Käytetään automaattisesti NTP:tä"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Käytetään automaattisesti lisättyjä NTP-palvelimia"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Käytetään automaattisesti tiettyjä NTP-palvelimia"
 ],
 "Automation script": [
  null,
  "Automaatio-komentosarja"
 ],
 "Balancer": [
  null,
  "Tasapainottaja"
 ],
 "Blade": [
  null,
  "Terä"
 ],
 "Blade enclosure": [
  null,
  "Teräkotelo"
 ],
 "Bond": [
  null,
  "Side"
 ],
 "Bridge": [
  null,
  "Silta"
 ],
 "Bridge port": [
  null,
  "Sillan portti"
 ],
 "Bridge port settings": [
  null,
  "Sillan porttiasetukset"
 ],
 "Broadcast": [
  null,
  "Yleislähetys"
 ],
 "Broken configuration": [
  null,
  "Rikkinäinen kokoonpano"
 ],
 "Bus expansion chassis": [
  null,
  "Väylän laajennusalusta"
 ],
 "Cancel": [
  null,
  "Peru"
 ],
 "Cannot forward login credentials": [
  null,
  "Kirjautumistietoja ei voi välittää eteenpäin"
 ],
 "Cannot schedule event in the past": [
  null,
  "Tapahtumaa ei voi aikatauluttaa menneisyyteen"
 ],
 "Carrier": [
  null,
  "Kuljetin"
 ],
 "Change": [
  null,
  "Vaihda"
 ],
 "Change system time": [
  null,
  "Vaihda järjestelmän aika"
 ],
 "Change the settings": [
  null,
  "Vaihda asetuksia"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Muutetut avaimet ovat usein seurausta käyttöjärjestelmän uudelleenasennuksesta. Odottamaton muutos voi kuitenkin tarkoittaa kolmannen osapuolen yritystä siepata yhteys."
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Asetuksien vaihtaminen katkaisee yhteyden palvelimeen, jolloin hallintakäyttöliittymä ei ole saatavilla."
 ],
 "Checking IP": [
  null,
  "Tarkistetaan IP"
 ],
 "Checking installed software": [
  null,
  "Tarkistetaan asennettu ohjelmisto"
 ],
 "Clear input value": [
  null,
  "Tyhjennä syöttöarvo"
 ],
 "Close": [
  null,
  "Sulje"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManagerin ja Firewalld:n Cockit-asetukset"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit ei saanut yhteyttä koneeseen."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit on palvelinhallintatyökalu, joka tekee ylläpidon helpoksi selaimen kautta. Liikkuminen päätteen ja verkkokäyttöliittymän välillä ei ole ongelma. Cockpitissä aloitettu palvelu voidaan lopettaa päätteessä. Samaten päätteessä näkyvä virheilmoitus voidaan nähdä myös Cockpitin journal-näkymässä."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit ei ole yhteensopiva järjestelmän ohjelmiston kanssa."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit ei ole asennettu"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit ei ole asennettu järjestelmässä."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit on täydellinen uusille ylläpitäjille. Sen avulla voi tehdä helposti toimenpiteitä kuten tallennustilan hallintaa, lokien tarkistamista sekä palveluiden käynnistämistä ja lopettamista. Voit monitoroida ja hallita useita palvelimia samanaikaisesti. Lisää ne yhdellä napsautuksella ja koneesi katsovat kavereidensa perään."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Kerää ja paketoi diagnostiikkaa ja tukitietoja"
 ],
 "Collect kernel crash dumps": [
  null,
  "Kerää ytimen kaatumisvedoksia"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Pilkuilla erotetut portit, alueet ja palvelut hyväksytään"
 ],
 "Compact PCI": [
  null,
  "Kompakti PCI"
 ],
 "Configuring": [
  null,
  "Asetetaan"
 ],
 "Configuring IP": [
  null,
  "Asetetaan IP"
 ],
 "Confirm key password": [
  null,
  "Vahvista avaimen salasana"
 ],
 "Confirm removal of $0": [
  null,
  "Vahvista $0:n poisto"
 ],
 "Connect automatically": [
  null,
  "Yhdistä automaattisesti"
 ],
 "Connection has timed out.": [
  null,
  "Yhteys aikakatkaistiin."
 ],
 "Connection will be lost": [
  null,
  "Yhteys tulee katoamaan"
 ],
 "Convertible": [
  null,
  "Muunnettavissa"
 ],
 "Copied": [
  null,
  "Kopioitu"
 ],
 "Copy": [
  null,
  "Kopio"
 ],
 "Copy to clipboard": [
  null,
  "Kopioi leikepöydälle"
 ],
 "Create $0": [
  null,
  "Luo $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Luo uusi SSH-avain ja valtuuta se"
 ],
 "Create it": [
  null,
  "Luo se"
 ],
 "Create new task file with this content.": [
  null,
  "Luo uusi tehtävätiedosto tällä sisällöllä."
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Kohteen $0 luominen katkaisee yhteyden palvelimeen, jolloin hallintakäyttöliittymä ei ole saatavilla."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Custom ports": [
  null,
  "Mukautetut portit"
 ],
 "Custom zones": [
  null,
  "Mukautetut vyöhykkeet"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "DNS-hakutoimialueet"
 ],
 "DNS search domains $val": [
  null,
  "DNS-hakutoimialueet $val"
 ],
 "Deactivating": [
  null,
  "Deaktivoidaan"
 ],
 "Delay": [
  null,
  "Viive"
 ],
 "Delete": [
  null,
  "Poista"
 ],
 "Delete $0": [
  null,
  "Poista $0"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Kohteen $0 poistaminen katkaisee yhteyden palvelimeen, jolloin hallintakäyttöliittymä ei ole saatavilla."
 ],
 "Description": [
  null,
  "Kuvaus"
 ],
 "Desktop": [
  null,
  "Työpöytä"
 ],
 "Detachable": [
  null,
  "Irrotettava"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "Disable the firewall": [
  null,
  "Poista palomuuri käytöstä"
 ],
 "Disabled": [
  null,
  "Ei käytössä"
 ],
 "Docking station": [
  null,
  "Telakka"
 ],
 "Downloading $0": [
  null,
  "Ladataan $0"
 ],
 "Dual rank": [
  null,
  "Kaksinkertainen sijoitus"
 ],
 "Edit": [
  null,
  "Muokkaa"
 ],
 "Edit VLAN settings": [
  null,
  "Muokkaa VLAN-asetuksia"
 ],
 "Edit WireGuard VPN": [
  null,
  "Muokkaa WireGuard VPN:ia"
 ],
 "Edit bond settings": [
  null,
  "Muokkaa sidosasetuksia"
 ],
 "Edit bridge settings": [
  null,
  "Muokkaa silta-asetuksia"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Muokkaa mukautettua palvelua $0-vyöhykkeellä"
 ],
 "Edit rules and zones": [
  null,
  "Muokkaa sääntöjä ja vyöhykkeitä"
 ],
 "Edit service": [
  null,
  "Muokkaa palvelua"
 ],
 "Edit service $0": [
  null,
  "Muokkaa palvelua $0"
 ],
 "Edit team settings": [
  null,
  "Muokkaa joukkueen asetuksia"
 ],
 "Embedded PC": [
  null,
  "Sulautettu tietokone"
 ],
 "Enable or disable the device": [
  null,
  "Ota laite käyttöön tai poista se käytöstä"
 ],
 "Enable service": [
  null,
  "Ota palvelu käyttöön"
 ],
 "Enable the firewall": [
  null,
  "Ota palomuuri käyttöön"
 ],
 "Enabled": [
  null,
  "Käytössä"
 ],
 "Endpoint": [
  null,
  "Päätepiste"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "\"Palvelimena\" toimiva päätepiste on määritettävä 'isäntä:portti':na, muuten se voidaan jättää tyhjäksi."
 ],
 "Enter a valid MAC address": [
  null,
  "Anna kelvollinen MAC-osoite"
 ],
 "Entire subnet": [
  null,
  "Koko aliverkko"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet MTU"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Esimerkki: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Esimerkki: 88,2019,nfs,rsync"
 ],
 "Excellent password": [
  null,
  "Erinomainen salasana"
 ],
 "Expansion chassis": [
  null,
  "Laajennusrunko"
 ],
 "Failed": [
  null,
  "Epäonnistui"
 ],
 "Failed to add port": [
  null,
  "Portin lisääminen epäonnistui"
 ],
 "Failed to add service": [
  null,
  "Palvelun lisääminen epäonnistui"
 ],
 "Failed to add zone": [
  null,
  "Vyöhykkeen lisääminen epäonnistui"
 ],
 "Failed to change password": [
  null,
  "Salasanan vaihtaminen epäonnistui"
 ],
 "Failed to edit service": [
  null,
  "Palvelun muokkaaminen epäonnistui"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "$0:n käyttöönotto firewalld:ssä epäonnistui"
 ],
 "Failed to save settings": [
  null,
  "Asetusten tallentaminen epäonnistui"
 ],
 "Filter services": [
  null,
  "Suodata palveluja"
 ],
 "Firewall": [
  null,
  "Palomuuri"
 ],
 "Firewall is not available": [
  null,
  "Palomuuri ei ole saatavilla"
 ],
 "Forward delay $forward_delay": [
  null,
  "Edelleenohjauksen viive $forward_delay"
 ],
 "Gateway": [
  null,
  "Yhdyskäytävä"
 ],
 "Gateway $gateway": [
  null,
  "Yhdyskäytävä $gateway"
 ],
 "General": [
  null,
  "Yleinen"
 ],
 "Generated": [
  null,
  "Luotu"
 ],
 "Go to now": [
  null,
  "Mene nyt"
 ],
 "Group": [
  null,
  "Ryhmä"
 ],
 "Hair pin mode": [
  null,
  "Hair Pin -tila"
 ],
 "Hairpin mode": [
  null,
  "Hairpin-tila"
 ],
 "Handheld": [
  null,
  "Kädessä pidettävä"
 ],
 "Hello time $hello_time": [
  null,
  "Tervehdysaika $hello_time"
 ],
 "Hide confirmation password": [
  null,
  "Piilota salasanan vahvistus"
 ],
 "Hide password": [
  null,
  "Piilota salasana"
 ],
 "Host key is incorrect": [
  null,
  "Koneen avain on väärin"
 ],
 "ID": [
  null,
  "Tunniste"
 ],
 "ID $id": [
  null,
  "Tunnus $id"
 ],
 "IP address": [
  null,
  "IP-osoite"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP-osoite reitityksen etuliitteellä. Erota useita arvoja pilkulla. Esimerkki: 192.0.2.0/24, 2001:db8::/32"
 ],
 "IP addresses": [
  null,
  "IP-osoitteet"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 settings": [
  null,
  "IPv4-asetukset"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "IPv6-asetukset"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Jos tämä jätetään tyhjäksi, tunniste generoidaan porttien palveluiden ja porttinumeroiden perusteella"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Jos sormenjälki on sama, napsauta 'Luota ja lisää yhteys'. Muussa tapauksessa älä muodosta yhteyttä ja ota yhteyttä järjestelmänvalvojaan."
 ],
 "Ignore": [
  null,
  "Ohita"
 ],
 "Inactive": [
  null,
  "Epäaktiivinen"
 ],
 "Included services": [
  null,
  "Mukana olevat palvelut"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Saapuvat pyynnöt estetään oletuksena. Lähteviä pyyntöjä ei estetä."
 ],
 "Install": [
  null,
  "Asennus"
 ],
 "Install software": [
  null,
  "Asennetaan ohjelmistoja"
 ],
 "Installing $0": [
  null,
  "Asennetaan $0"
 ],
 "Interface": [
  null,
  "Liitäntä",
  "Liitännät"
 ],
 "Interface members": [
  null,
  "Liitännän jäsenet"
 ],
 "Interfaces": [
  null,
  "Liitännät"
 ],
 "Internal error": [
  null,
  "Sisäinen virhe"
 ],
 "Invalid DNS address: $0": [
  null,
  "Ei kelvollinen DNS-osoite $0"
 ],
 "Invalid IP address '$0'": [
  null,
  "Ei kelvollinen IP-osoite '$0'"
 ],
 "Invalid IP address: $0": [
  null,
  "Ei kelvollinen IP-osoite '$0'"
 ],
 "Invalid address $0": [
  null,
  "Ei kelvollinen osoite $0"
 ],
 "Invalid date format": [
  null,
  "Virheellinen päivämuoto"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Virheellinen päivämuoto ja aikamuoto"
 ],
 "Invalid destination address: $0": [
  null,
  "Ei kelvollinen kohdeosoite $0"
 ],
 "Invalid file permissions": [
  null,
  "Virheelliset tiedosto-oikeudet"
 ],
 "Invalid gateway address: $0": [
  null,
  "Ei kelvollinen yhdyskäytävän osoite $0"
 ],
 "Invalid metric $0": [
  null,
  "Virheellinen metriikka $0"
 ],
 "Invalid port number": [
  null,
  "Virheellinen porttinumero"
 ],
 "Invalid prefix $0": [
  null,
  "Virheellinen etuliite $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Virheellinen etuliite tai verkkopeite $0"
 ],
 "Invalid range": [
  null,
  "Ei kelvollinen alue"
 ],
 "Invalid time format": [
  null,
  "Virheellinen aikamuoto"
 ],
 "Invalid timezone": [
  null,
  "Virheellinen aikavyöhyke"
 ],
 "IoT gateway": [
  null,
  "IoT -yhdyskäytävä"
 ],
 "Keep connection": [
  null,
  "Pidä yhteys"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Key password": [
  null,
  "Avaimen salasana"
 ],
 "LACP key": [
  null,
  "LACP-avain"
 ],
 "Laptop": [
  null,
  "Kannettava"
 ],
 "Learn more": [
  null,
  "Opi lisää"
 ],
 "Link down delay": [
  null,
  "Linkki alas -viive"
 ],
 "Link local": [
  null,
  "Yksityisosoite"
 ],
 "Link monitoring": [
  null,
  "Linkin valvonta"
 ],
 "Link up delay": [
  null,
  "Linkki ylös -viive"
 ],
 "Link watch": [
  null,
  "Linkin seuranta"
 ],
 "Listen port": [
  null,
  "Kuunteluportti"
 ],
 "Listen port must be a number": [
  null,
  "Kuunteluportin on oltava numero"
 ],
 "Load balancing": [
  null,
  "Kuormantasaus"
 ],
 "Loading system modifications...": [
  null,
  "Ladataan järjestelmän muutoksia ..."
 ],
 "Log in": [
  null,
  "Kirjaudu sisään"
 ],
 "Log in to $0": [
  null,
  "Kirjaudu kohteeseen $0"
 ],
 "Log messages": [
  null,
  "Kirjaa viestit"
 ],
 "Login failed": [
  null,
  "Kirjautuminen epäonnistui"
 ],
 "Low profile desktop": [
  null,
  "Matalan tason työpöytä"
 ],
 "Lunch box": [
  null,
  "Eväslaatikko"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (suositeltu)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU:n tulee olla positiivinen numero"
 ],
 "Main server chassis": [
  null,
  "Pääpalvelimen runko"
 ],
 "Manage storage": [
  null,
  "Tallennustilan hallinta"
 ],
 "Managed interfaces": [
  null,
  "Hallitut liitännät"
 ],
 "Manual": [
  null,
  "Käsikirja"
 ],
 "Manually": [
  null,
  "Manuaalisesti"
 ],
 "Maximum message age $max_age": [
  null,
  "Viestin enimmäisikä $max_age"
 ],
 "Message to logged in users": [
  null,
  "Viesti sisäänkirjautuneille käyttäjille"
 ],
 "Metric": [
  null,
  "Mittarit"
 ],
 "Mini PC": [
  null,
  "Minitietokone"
 ],
 "Mini tower": [
  null,
  "Minitorni"
 ],
 "Mode": [
  null,
  "Tila"
 ],
 "Monitoring interval": [
  null,
  "Monitorointiväli"
 ],
 "Monitoring targets": [
  null,
  "Kohteiden seuranta"
 ],
 "Multi-system chassis": [
  null,
  "Monijärjestelmäinen alusta"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Useita osoitteita voidaan määrittää käyttämällä pilkkuja tai välilyöntejä erottimina."
 ],
 "NSNA ping": [
  null,
  "NSNA:n ping"
 ],
 "NTP server": [
  null,
  "NTP-palvelin"
 ],
 "Name": [
  null,
  "Nimi"
 ],
 "Need at least one NTP server": [
  null,
  "Tarvitaan vähintään yksi NTP-palvelin"
 ],
 "Network bond": [
  null,
  "Verkkosidos"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Verkkolaitteet ja kaaviot vaativat NetworkManagerin"
 ],
 "Network logs": [
  null,
  "Verkkolokit"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager ei ole asennettu"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager ei ole käynnissä"
 ],
 "Networking": [
  null,
  "Verkko"
 ],
 "New password was not accepted": [
  null,
  "Uutta salasanaa ei hyväksytty"
 ],
 "No": [
  null,
  "Ei"
 ],
 "No carrier": [
  null,
  "Ei kantajaa"
 ],
 "No delay": [
  null,
  "Ei viivettä"
 ],
 "No description available": [
  null,
  "Ei kuvausta saatavilla"
 ],
 "No peers added.": [
  null,
  "Ei lisätty vertaisia."
 ],
 "No results found": [
  null,
  "Tuloksia ei löytynyt"
 ],
 "No such file or directory": [
  null,
  "Tiedostoa tai hakemistoa ei löydy"
 ],
 "No system modifications": [
  null,
  "Ei järjestelmän muutoksia"
 ],
 "None": [
  null,
  "Ei yhtään"
 ],
 "Not a valid private key": [
  null,
  "Ei kelvollinen yksityinen avain"
 ],
 "Not authorized to disable the firewall": [
  null,
  "Ei oikeutta poistaa palomuuri käytöstä"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Ei oikeutta ottaa käyttöön palomuuria"
 ],
 "Not available": [
  null,
  "Ei saatavilla"
 ],
 "Not permitted to configure network devices": [
  null,
  "Verkkolaitteiden määrittäminen ei sallittu"
 ],
 "Not permitted to perform this action.": [
  null,
  "Ei oikeutta suorittaa tätä toimintoa."
 ],
 "Not synchronized": [
  null,
  "Ei synkronisoitu"
 ],
 "Notebook": [
  null,
  "Muistikirja"
 ],
 "Occurrences": [
  null,
  "Tapahtumat"
 ],
 "Ok": [
  null,
  "Hyvä on"
 ],
 "Old password not accepted": [
  null,
  "Vanhaa salasanaa ei hyväksytty"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Kun Cockpit on asennettu, ota se käyttöön 'systemctl enable --now cockpit.socket'."
 ],
 "Options": [
  null,
  "Valinnat"
 ],
 "Other": [
  null,
  "Muu"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kaatui"
 ],
 "Parent": [
  null,
  "Vanhemmat"
 ],
 "Parent $parent": [
  null,
  "$parent-vanhempi"
 ],
 "Part of $0": [
  null,
  "Osa kokonaisuudesta $0"
 ],
 "Passive": [
  null,
  "Passiivinen"
 ],
 "Password": [
  null,
  "Salasana"
 ],
 "Password is not acceptable": [
  null,
  "Salasana ei ole hyväksyttävä"
 ],
 "Password is too weak": [
  null,
  "Salasana on liian heikko"
 ],
 "Password not accepted": [
  null,
  "Salasanaa ei hyväksytty"
 ],
 "Paste": [
  null,
  "Siirrä"
 ],
 "Paste error": [
  null,
  "Liittämisvirhe"
 ],
 "Paste existing key": [
  null,
  "Liitä olemassa oleva avain"
 ],
 "Path cost": [
  null,
  "Polun kustannus"
 ],
 "Path cost $path_cost": [
  null,
  "Polun kustannus $path_cost"
 ],
 "Path to file": [
  null,
  "Polku tiedostoon"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "Vertaisella #$0 on virheellinen päätepisteportti. Portin on oltava numero."
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820, [2001:db8::1]:51820 or example.com:51820": [
  null,
  "Vertaislaitteella #$0 on virheellinen päätepiste. Se on määritettävä muodossa isäntä:portti, esim. 1.2.3.4:51820, [2001:db8::1]:51820 tai esimerkiksi.com:51820"
 ],
 "Peers": [
  null,
  "Osapuolet"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Vertaiset ovat muita koneita, jotka muodostavat yhteyden tähän koneeseen. Muiden koneiden julkiset avaimet jaetaan toistensa kanssa."
 ],
 "Peripheral chassis": [
  null,
  "Lisälaitteen kotelo"
 ],
 "Permanent": [
  null,
  "Pysyvä"
 ],
 "Pick date": [
  null,
  "Valitse päivämäärä"
 ],
 "Ping interval": [
  null,
  "Ping-väli"
 ],
 "Ping target": [
  null,
  "Pingin kohteet"
 ],
 "Pizza box": [
  null,
  "Pizza-laatikko"
 ],
 "Please install the $0 package": [
  null,
  "Asenna $0-paketti"
 ],
 "Portable": [
  null,
  "Kannettava"
 ],
 "Ports": [
  null,
  "Portit"
 ],
 "Prefix length": [
  null,
  "Etuliitteen pituus"
 ],
 "Prefix length or netmask": [
  null,
  "Etuliitteen pituus tai verkkopeite"
 ],
 "Preparing": [
  null,
  "Valmistellaan"
 ],
 "Present": [
  null,
  "Nykyinen"
 ],
 "Preserve": [
  null,
  "Säilytä"
 ],
 "Primary": [
  null,
  "Ensisijainen"
 ],
 "Priority": [
  null,
  "Prioriteetti"
 ],
 "Priority $priority": [
  null,
  "Prioriteetti $priority"
 ],
 "Private key": [
  null,
  "Yksityinen avain"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Kysely 'ssh-add':in kautta aikakatkaistiin"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Kysely 'ssh-keygen':in kautta aikakatkaistiin"
 ],
 "Public key": [
  null,
  "Julkinen avain"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Julkinen avain luodaan, kun kelvollinen yksityinen avain välitetään"
 ],
 "RAID chassis": [
  null,
  "RAID-runko"
 ],
 "Rack mount chassis": [
  null,
  "Räkkiin liitettävä runko"
 ],
 "Random": [
  null,
  "Satunnainen"
 ],
 "Range": [
  null,
  "Alue"
 ],
 "Range must be strictly ordered": [
  null,
  "Alueen on oltava tiukasti järjestetty"
 ],
 "Reboot": [
  null,
  "Käynnistä uudelleen"
 ],
 "Receiving": [
  null,
  "Vastaanotetaan"
 ],
 "Regenerate": [
  null,
  "Luo uudelleen"
 ],
 "Removals:": [
  null,
  "Poistot:"
 ],
 "Remove $0": [
  null,
  "Poista $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Poista palvelu $0 vyöhykkeeltä $1"
 ],
 "Remove item": [
  null,
  "Poista kohde"
 ],
 "Remove service $0": [
  null,
  "Poista palvelu $0"
 ],
 "Remove zone $0": [
  null,
  "Poista vyöhyke $0"
 ],
 "Removing $0": [
  null,
  "Poistetaan $0"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Verkkoliitännän $0 poistaminen katkaisee yhteyden palvelimeen, jolloin hallintakäyttöliittymä ei ole saatavilla."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "cockpit-palvelun poistaminen voi johtaa siihen, että verkkokonsoli ei ole tavoitettavissa. Varmista, että tämä vyöhyke ei koske nykyistä verkkokonsoliyhteyttäsi."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Vyöhykkeen poistaminen poistaa kaikki sen sisäiset palvelut."
 ],
 "Restoring connection": [
  null,
  "Palautetaan yhteys"
 ],
 "Round robin": [
  null,
  "kiertovuorottelu"
 ],
 "Routes": [
  null,
  "Reitit"
 ],
 "Row expansion": [
  null,
  "Rivin laajennus"
 ],
 "Row select": [
  null,
  "Rivin valinta"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Suorita tämä komento luotetussa verkossa tai fyysisesti etäkoneella:"
 ],
 "Runner": [
  null,
  "Suorittaja"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-avain"
 ],
 "SSH key login": [
  null,
  "SSH-avaimen sisäänkirjautuminen"
 ],
 "STP forward delay": [
  null,
  "STP-ohjauksen viive"
 ],
 "STP hello time": [
  null,
  "STP-hello-aika"
 ],
 "STP maximum message age": [
  null,
  "STP-viestin enimmäisikä"
 ],
 "STP priority": [
  null,
  "STP:n prioriteetti"
 ],
 "Save": [
  null,
  "Tallenna"
 ],
 "Sealed-case PC": [
  null,
  "Suljettu tietokonekotelo"
 ],
 "Search domain": [
  null,
  "Etsi verkkoaluetta"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linuxin asetukset ja ongelmanratkaisu"
 ],
 "Select an option": [
  null,
  "Valitse vaihtoehto"
 ],
 "Select method": [
  null,
  "Valitse menetelmä"
 ],
 "Sending": [
  null,
  "Lähetetään"
 ],
 "Server": [
  null,
  "Palvelin"
 ],
 "Server has closed the connection.": [
  null,
  "Palvelin on sulkenut yhteyden."
 ],
 "Service": [
  null,
  "Palvelu"
 ],
 "Services": [
  null,
  "Palvelut"
 ],
 "Set time": [
  null,
  "Aseta aika"
 ],
 "Set to": [
  null,
  "Aseta tähän"
 ],
 "Shared": [
  null,
  "Jaettu"
 ],
 "Shell script": [
  null,
  "Komentotulkin komentosarja"
 ],
 "Shift+Insert": [
  null,
  "Vaihto + Syöttö"
 ],
 "Show confirmation password": [
  null,
  "Näytä salasanan vahvistus"
 ],
 "Show password": [
  null,
  "Näytä salasana"
 ],
 "Shut down": [
  null,
  "Sammuta"
 ],
 "Single rank": [
  null,
  "Yksi sijoitus"
 ],
 "Sorted from least to most trusted": [
  null,
  "Lajiteltu vähiten luotettavista luotetuimpiin"
 ],
 "Space-saving computer": [
  null,
  "Tilaa säästävä tietokone"
 ],
 "Spanning tree protocol": [
  null,
  "Spanning tree -protokolla"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Spanning tree -protokolla (STP)"
 ],
 "Specific time": [
  null,
  "Tietty aika"
 ],
 "Stable": [
  null,
  "Vakaa"
 ],
 "Start service": [
  null,
  "Käynnistä palvelu"
 ],
 "Status": [
  null,
  "Tila"
 ],
 "Stick PC": [
  null,
  "Tikku-PC"
 ],
 "Sticky": [
  null,
  "Tahmea"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "Strong password": [
  null,
  "Vahva salasana"
 ],
 "Sub-Chassis": [
  null,
  "Alirunko"
 ],
 "Sub-Notebook": [
  null,
  "Pieni kannettava tietokone"
 ],
 "Switch off $0": [
  null,
  "Kytke $0 pois päältä"
 ],
 "Switch on $0": [
  null,
  "Kytke $0 päälle"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 kytkeminen pois päältä katkaisee yhteyden palvelimeen ja tekee hallinnon käyttöliittymän ei saataville."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Laitteen $0 kytkeminen päälle katkaisee yhteyden palvelimeen, jolloin hallintakäyttöliittymä ei ole saatavilla."
 ],
 "Synchronized": [
  null,
  "Synkronoitu"
 ],
 "Synchronized with $0": [
  null,
  "Synkronoi palvelimen $0 kanssa"
 ],
 "Synchronizing": [
  null,
  "Synkronoidaan"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tablet": [
  null,
  "Tabletti"
 ],
 "Team": [
  null,
  "Joukkue"
 ],
 "Team port": [
  null,
  "Joukkueen portti"
 ],
 "Team port settings": [
  null,
  "Joukkueen portin asetukset"
 ],
 "Testing connection": [
  null,
  "Testataan yhteyttä"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Käyttäjän $0:n SSH-avain $1 koneella $2 lisätään käyttäjän $4 tiedostoon $3 koneella $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-avain $0 on käytettävissä koko istunnon ajan ja on käytettävissä myös muille koneille sisäänkirjautumista varten."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-avain koneelle $0 sisäänkirjautumista varten on suojattu salasanalla, eikä kone salli salasanalla kirjautumista. Anna avaimen $1 salasana."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-avain koneelle $0 sisäänkirjautumista varten on suojattu. Voit kirjautua sisään joko kirjautumissalasanallasi tai antamalla avaimen $1 salasanan."
 ],
 "The cockpit service is automatically included": [
  null,
  "Palvelu cockpit sisältyy automaattisesti"
 ],
 "The fingerprint should match:": [
  null,
  "Sormenjäljen tulee vastata:"
 ],
 "The key password can not be empty": [
  null,
  "Avaimen salasana ei voi olla tyhjä"
 ],
 "The key passwords do not match": [
  null,
  "Avainsalasanat eivät täsmää"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Sisäänkirjautunut käyttäjä ei saa tarkastella järjestelmän muutoksia"
 ],
 "The password can not be empty": [
  null,
  "Salasana ei voi olla tyhjä"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Tuloksena oleva sormenjälki sopii jakaa julkisilla menetelmillä, mukaan lukien sähköposti."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Tuloksena oleva sormenjälki sopii jaettavaksi julkisilla menetelmillä, mukaan lukien sähköposti. Jos pyydät jotakuta toista suorittamaan vahvistuksen puolestasi, hän voi lähettää tulokset millä tahansa menetelmällä."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Palvelin kieltäytyi tunnistautumista käyttäen mitään tuetuista tavoista."
 ],
 "There are no active services in this zone": [
  null,
  "Tällä vyöhykkeellä ei ole aktiivisia palveluja"
 ],
 "This device cannot be managed here.": [
  null,
  "Tätä laitetta ei voida hallita täällä."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tämä työkalu asettaa SELinux-käytännön ja auttaa käytäntörikkeiden ymmärtämisessä ja ratkaisemisessa."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Tämä työkalu määrittää järjestelmän kirjoittamaan ytimen kaatumisvedoksia. Se tukee \"paikallisia\" (levy-), \"ssh\"- ja \"nfs\"-vedoskohteita."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tämä työkalu luo arkiston konfiguraatio- ja diagnostiikkatiedoista käynnissä olevasta järjestelmästä. Arkisto voidaan tallentaa paikallisesti tai keskitetysti tallennus- tai seurantatarkoituksiin tai se voidaan lähettää teknisen tuen edustajille, kehittäjille tai järjestelmänvalvojille auttamaan teknisten vikojen etsinnässä ja virheenkorjauksessa."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tämä työkalu hallinnoi paikallista tallennustilaa, kuten tiedostojärjestelmiä, LVM2-taltioryhmiä ja NFS-liitoksia."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tämä työkalu hallitsee verkkoyhteyksiä, kuten sidoksia, siltoja, ryhmiä, VLAN-verkkoja ja palomuureja NetworkManagerin ja Firewalld:n avulla. NetworkManager ei ole yhteensopiva Ubuntun oletusarvoisten systemd-networkd- ja Debianin ifupdown-komentosarjojen kanssa."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Tämä vyöhyke sisältää cockpit-palvelun. Varmista, että tämä vyöhyke ei koske nykyistä verkkokonsoliyhteyttäsi."
 ],
 "Time zone": [
  null,
  "Aikavyöhyke"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Tarkista koneen avaimen sormenjälki varmistaaksesi, että haitallinen kolmas osapuoli ei sieppaa yhteyttä:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Vahvistaaksesi sormenjäljen, suorita seuraava koneella $0 istuessasi fyysisesti koneen ääressä tai luotettavan verkon kautta:"
 ],
 "Toggle date picker": [
  null,
  "Vaihda päivämäärän valitsin"
 ],
 "Too much data": [
  null,
  "Liian paljon dataa"
 ],
 "Total size: $0": [
  null,
  "Koko yhteensä: $0"
 ],
 "Tower": [
  null,
  "Torni"
 ],
 "Transmitting": [
  null,
  "Lähetetään"
 ],
 "Troubleshoot…": [
  null,
  "Vianetsintä…"
 ],
 "Trust and add host": [
  null,
  "Luota ja lisää isäntä"
 ],
 "Trust level": [
  null,
  "Luottamustaso"
 ],
 "Trying to synchronize with $0": [
  null,
  "Yritetään synkronoida palvelimen $0 kanssa"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Ei voida kirjautua sisään $0:iin SSH-avaimella. Syötä salasana."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Ei voida kirjautua sisään koneelle $0. Kone ei hyväksy salasanakirjautumista tai mitään SSH-avaimistasi."
 ],
 "Unexpected error": [
  null,
  "Odottamaton virhe"
 ],
 "Unknown": [
  null,
  "Tuntematon"
 ],
 "Unknown \"$0\"": [
  null,
  "Tuntematon \"$0\""
 ],
 "Unknown configuration": [
  null,
  "Tuntematon konfiguraatio"
 ],
 "Unknown host: $0": [
  null,
  "Tuntematon isäntä: $0"
 ],
 "Unknown service name": [
  null,
  "Tuntematon palvelun nimi"
 ],
 "Unmanaged interfaces": [
  null,
  "Hallitsemattomat liitännät"
 ],
 "Untrusted host": [
  null,
  "Epäluotettava kone"
 ],
 "Use $0": [
  null,
  "Käytä $0:a"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "VLAN-tunnus"
 ],
 "Verify fingerprint": [
  null,
  "Vahvista sormenjälki"
 ],
 "View all logs": [
  null,
  "Katso kaikki lokit"
 ],
 "View automation script": [
  null,
  "Näytä automaatio-komentosarja"
 ],
 "Visit firewall": [
  null,
  "Käy palomuurissa"
 ],
 "Waiting": [
  null,
  "Odotetaan"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Odotetaan muiden ohjelmistojen hallintatoimintojen päättymistä"
 ],
 "Weak password": [
  null,
  "Heikko salasana"
 ],
 "Web Console for Linux servers": [
  null,
  "Verkkokonsoli Linux-palvelimille"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Asetetaan \"Automaattinen\""
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "Kyllä"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Yhdistät koneeseen $0 ensimmäistä kertaa."
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Sinulla ei ole valtuuksia muokata palomuuria."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Selaimesi ei salli liittämistä pikavalikosta. Voit käyttää Vaihto+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Istuntosi on päätetty."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Istuntosi on vahventunut. Ole hyvä ja kirjaudu uudelleen sisään."
 ],
 "Zone": [
  null,
  "Alue"
 ],
 "[binary data]": [
  null,
  "[binääridata]"
 ],
 "[no data]": [
  null,
  "[ei dataa]"
 ],
 "edit": [
  null,
  "muokkaa"
 ],
 "in less than a minute": [
  null,
  "alle minuutissa"
 ],
 "less than a minute ago": [
  null,
  "alle minuutti sitten"
 ],
 "password quality": [
  null,
  "salasanan laatu"
 ],
 "show less": [
  null,
  "näytä vähemmän"
 ],
 "show more": [
  null,
  "näytä enemmän"
 ],
 "wireguard-tools package is not installed": [
  null,
  "wireguard-tools-pakettia ei ole asennettu"
 ]
});
