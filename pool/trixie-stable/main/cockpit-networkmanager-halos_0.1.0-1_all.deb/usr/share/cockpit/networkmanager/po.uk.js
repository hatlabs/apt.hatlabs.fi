cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 ГіБ"
 ],
 "$0 active zone": [
  null,
  "$0 активна зона",
  "$0 активні зони",
  "$0 активних зон"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дні",
  "$0 днів"
 ],
 "$0 exited with code $1": [
  null,
  "$0 завершено роботу з кодом $1"
 ],
 "$0 failed": [
  null,
  "Помилка $0"
 ],
 "$0 hour": [
  null,
  "$0 година",
  "$0 години",
  "$0 годин"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 немає у жодному зі сховищ."
 ],
 "$0 key changed": [
  null,
  "Змінено ключ $0"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 завершено з сигналом $1"
 ],
 "$0 minute": [
  null,
  "$0 хвилина",
  "$0 хвилини",
  "$0 хвилин"
 ],
 "$0 month": [
  null,
  "$0 місяць",
  "$0 місяці",
  "$0 місяців"
 ],
 "$0 week": [
  null,
  "$0 тиждень",
  "$0 тижні",
  "$0 тижнів"
 ],
 "$0 will be installed.": [
  null,
  "Буде встановлено $0."
 ],
 "$0 year": [
  null,
  "$0 рік",
  "$0 роки",
  "$0 років"
 ],
 "$0 zone": [
  null,
  "зона $0"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 hour": [
  null,
  "1 година"
 ],
 "1 minute": [
  null,
  "1 хвилина"
 ],
 "1 week": [
  null,
  "1 тиждень"
 ],
 "20 minutes": [
  null,
  "20 хвилин"
 ],
 "40 minutes": [
  null,
  "40 хвилин"
 ],
 "5 minutes": [
  null,
  "5 хвилин"
 ],
 "6 hours": [
  null,
  "6 годин"
 ],
 "60 minutes": [
  null,
  "60 хвилин"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "На $0 не встановлено сумісної версії Cockpit."
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Мережевий зв'язок поєднує декілька інтерфейсів мережі у один логічний інтерфейс із вищою пропускною здатністю або вищим рівнем резервування."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Буде створено новий ключ SSH у $0 для $1 на $2 і його буде додано до файла $3 $4 на $5."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "Стеження за ARP"
 ],
 "ARP ping": [
  null,
  "Луна-імпульс ARP"
 ],
 "Absent": [
  null,
  "Відсутній"
 ],
 "Acceptable password": [
  null,
  "Прийнятний пароль"
 ],
 "Actions": [
  null,
  "Дії"
 ],
 "Active": [
  null,
  "Активний"
 ],
 "Active backup": [
  null,
  "Активне резервування"
 ],
 "Adaptive load balancing": [
  null,
  "Адаптивне урівноваження навантаження"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Адаптивне урівноваження навантаження за передаванням"
 ],
 "Add": [
  null,
  "Додати"
 ],
 "Add $0": [
  null,
  "Додати $0"
 ],
 "Add DNS server": [
  null,
  "Додати сервер DNS"
 ],
 "Add VLAN": [
  null,
  "Додати VLAN"
 ],
 "Add VPN": [
  null,
  "Додати VPN"
 ],
 "Add WireGuard VPN": [
  null,
  "Додати WireGuard VPN"
 ],
 "Add a new zone": [
  null,
  "Додати нову зону"
 ],
 "Add address": [
  null,
  "Додати адресу"
 ],
 "Add bond": [
  null,
  "Додати зв’язок"
 ],
 "Add bridge": [
  null,
  "Додати місток"
 ],
 "Add member": [
  null,
  "Додати учасника"
 ],
 "Add new zone": [
  null,
  "Додати нову зону"
 ],
 "Add peer": [
  null,
  "Додати вузол"
 ],
 "Add ports": [
  null,
  "Додати порти"
 ],
 "Add ports to $0 zone": [
  null,
  "Додати порти до зони $0"
 ],
 "Add route": [
  null,
  "Додати маршрут"
 ],
 "Add search domain": [
  null,
  "Додати домен пошуку"
 ],
 "Add services": [
  null,
  "Додавання служб"
 ],
 "Add services to $0 zone": [
  null,
  "Додати служби до зони $0"
 ],
 "Add services to zone $0": [
  null,
  "Додати служби до зони $0"
 ],
 "Add team": [
  null,
  "Додати команду"
 ],
 "Add zone": [
  null,
  "Додати зону"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Додавання $0 призведе до розірвання з’єднання із сервером і зробить адміністративний інтерфейс користувача недоступним."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Додавання нетипових портів призведе до перезавантаження firewalld. Це перезавантаження спричинить втрату усіх налаштувань окремого сеансу роботи!"
 ],
 "Additional DNS $val": [
  null,
  "Додатковий DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Додаткові домени пошуку DNS $val"
 ],
 "Additional address $val": [
  null,
  "Додаткова адреса $val"
 ],
 "Additional packages:": [
  null,
  "Додаткові пакунки:"
 ],
 "Additional ports": [
  null,
  "Додаткові порти"
 ],
 "Address": [
  null,
  "Адреса"
 ],
 "Address $val": [
  null,
  "Адреса $val"
 ],
 "Addresses": [
  null,
  "Адреси"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Адреси не форматовано належним чином"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Адміністрування за допомогою вебконсолі Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Розширене TCA"
 ],
 "All-in-one": [
  null,
  "Усе в одному"
 ],
 "Allowed IPs": [
  null,
  "Дозволені IP-адреси"
 ],
 "Allowed addresses": [
  null,
  "Дозволені адреси"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Документація з ролей Ansible"
 ],
 "Authenticating": [
  null,
  "Автентифікація"
 ],
 "Authentication": [
  null,
  "Розпізнавання"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Щоб отримати доступ до виконання привілейованих завдань за допомогою вебконсолі Cockpit, слід пройти розпізнавання"
 ],
 "Authorize SSH key": [
  null,
  "Уповноважити ключ SSH"
 ],
 "Automatic": [
  null,
  "Автоматично"
 ],
 "Automatic (DHCP only)": [
  null,
  "Автоматично (лише DHCP)"
 ],
 "Automatically using NTP": [
  null,
  "Автоматично на основі NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Автоматично за допомогою додаткових серверів NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматично за допомогою певних серверів NTP"
 ],
 "Automation script": [
  null,
  "Скрипт автоматизації"
 ],
 "Balancer": [
  null,
  "Балансир"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Обгортка Blade"
 ],
 "Bond": [
  null,
  "Прив’язка"
 ],
 "Bridge": [
  null,
  "Міст"
 ],
 "Bridge port": [
  null,
  "Порт містка"
 ],
 "Bridge port settings": [
  null,
  "Параметри порту містка"
 ],
 "Broadcast": [
  null,
  "Трансляція"
 ],
 "Broken configuration": [
  null,
  "Помилки у налаштуваннях"
 ],
 "Bus expansion chassis": [
  null,
  "Апаратний блок розширення каналу"
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Cannot forward login credentials": [
  null,
  "Не вдалося переспрямувати реєстраційні дані для входу"
 ],
 "Cannot schedule event in the past": [
  null,
  "Не можна планувати подію на минуле"
 ],
 "Carrier": [
  null,
  "Носій сигналу"
 ],
 "Change": [
  null,
  "Змінити"
 ],
 "Change system time": [
  null,
  "Змінити системний час"
 ],
 "Change the settings": [
  null,
  "Змінити параметри"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Зміна ключів часто є результатом перевстановлення операційної системи. Втім, неочікувана зміна може вказувати на сторонню спробу перехопити дані вашого з'єднання."
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Зміна параметрів призведе до розірвання з’єднання із сервером і зробить адміністративний інтерфейс користувача недоступним."
 ],
 "Checking IP": [
  null,
  "Перевіряємо IP"
 ],
 "Checking installed software": [
  null,
  "Перевіряємо встановлене програмне забезпечення"
 ],
 "Clear input value": [
  null,
  "Вилучити вхідне значення"
 ],
 "Close": [
  null,
  "Закрити"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Налаштування Cockpit для NetworkManager і Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit не вдалося встановити зв’язок із вказаним вузлом."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit — програма для керування сервером, яка полегшує адміністрування ваших серверів під керуванням Linux за допомогою програми для перегляду сторінок інтернету. Ви зможете одночасно використовувати термінал і вебінструмент. Службу, яку було запущено за допомогою Cockpit, можна зупинити за допомогою термінала. І навпаки, якщо трапиться помилка у терміналі, ви побачите її у інтерфейсі журналу Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit є несумісним із програмним забезпеченням цієї системи."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit не встановлено"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit у цій системі не встановлено."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit — чудовий інструмент для системних адміністраторів-початківців. За його допомогою вони без проблем впораються із простими завданнями, зокрема адмініструванням сховищ даних, інспектуванням журналів та запуском і зупиненням служб. Ви зможете одночасно стежити за роботою декількох серверів і адмініструвати ці сервери. Просто додайте їх одним клацанням кнопкою миші і ваш комп’ютер сам нагляне за своїми приятелями."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Збирати і пакувати діагностичні дані і дані щодо підтримки"
 ],
 "Collect kernel crash dumps": [
  null,
  "Збирати дампи аварій ядра"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Можна використовувати відокремлені комами порти, діапазони і служби"
 ],
 "Compact PCI": [
  null,
  "Компактний PCI"
 ],
 "Configuring": [
  null,
  "Налаштовування"
 ],
 "Configuring IP": [
  null,
  "Налаштовуємо IP"
 ],
 "Confirm key password": [
  null,
  "Підтвердження пароля до ключа"
 ],
 "Confirm removal of $0": [
  null,
  "Підтвердження вилучення $0"
 ],
 "Connect automatically": [
  null,
  "З’єднуватися автоматично"
 ],
 "Connection has timed out.": [
  null,
  "Вичерпано час очікування на з’єднання."
 ],
 "Connection will be lost": [
  null,
  "З’єднання буде розірвано"
 ],
 "Convertible": [
  null,
  "Змінюваний"
 ],
 "Copied": [
  null,
  "Скопійовано"
 ],
 "Copy": [
  null,
  "Копіювати"
 ],
 "Copy to clipboard": [
  null,
  "Копіювати до буфера"
 ],
 "Create $0": [
  null,
  "Створити $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Створити ключ SSH і уповноважити його"
 ],
 "Create it": [
  null,
  "Створити"
 ],
 "Create new task file with this content.": [
  null,
  "Створити файл завдання із цим вмістом."
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Створення цієї $0 призведе до розірвання з’єднання із сервером і зробить адміністративний інтерфейс користувача недоступним."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Custom ports": [
  null,
  "Нетипові порти"
 ],
 "Custom zones": [
  null,
  "Нетипові зони"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "Домени пошуку DNS"
 ],
 "DNS search domains $val": [
  null,
  "Домени пошуку DNS $val"
 ],
 "Deactivating": [
  null,
  "Деактивація"
 ],
 "Delay": [
  null,
  "Затримка"
 ],
 "Delete": [
  null,
  "Вилучити"
 ],
 "Delete $0": [
  null,
  "Вилучити $0"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Вилучення $0 призведе до розірвання з’єднання із сервером і зробить адміністративний інтерфейс користувача недоступним."
 ],
 "Description": [
  null,
  "Опис"
 ],
 "Desktop": [
  null,
  "Робоча станція"
 ],
 "Detachable": [
  null,
  "Змінний"
 ],
 "Diagnostic reports": [
  null,
  "Діагностичні звіти"
 ],
 "Disable the firewall": [
  null,
  "Вимкнути брандмауер"
 ],
 "Disabled": [
  null,
  "Вимкнено"
 ],
 "Docking station": [
  null,
  "Станція заряджання"
 ],
 "Downloading $0": [
  null,
  "Отримуємо $0"
 ],
 "Dual rank": [
  null,
  "Подвійний ранг"
 ],
 "Edit": [
  null,
  "Змінити"
 ],
 "Edit VLAN settings": [
  null,
  "Редагувати параметри VLAN"
 ],
 "Edit WireGuard VPN": [
  null,
  "Редагувати WireGuard VPN"
 ],
 "Edit bond settings": [
  null,
  "Редагувати параметри прив'язки"
 ],
 "Edit bridge settings": [
  null,
  "Редагувати параметри містка"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Редагувати нетипову службу у зоні $0"
 ],
 "Edit rules and zones": [
  null,
  "Редагування правил і зон"
 ],
 "Edit service": [
  null,
  "Змінити службу"
 ],
 "Edit service $0": [
  null,
  "Змінити службу $0"
 ],
 "Edit team settings": [
  null,
  "Редагувати параметри команди"
 ],
 "Embedded PC": [
  null,
  "Вбудований ПК"
 ],
 "Enable or disable the device": [
  null,
  "Увімкнути або вимкнути пристрій"
 ],
 "Enable service": [
  null,
  "Увімкнути службу"
 ],
 "Enable the firewall": [
  null,
  "Увімкнути брандмауер"
 ],
 "Enabled": [
  null,
  "Увімкнено"
 ],
 "Endpoint": [
  null,
  "Кінцева точка"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "Слід вказати кінцеву точку, яка працюватиме як «сервер», у форматі вузол:порт, інакше, можна не заповнювати."
 ],
 "Enter a valid MAC address": [
  null,
  "Введіть коректну MAC-адресу"
 ],
 "Entire subnet": [
  null,
  "Уся підмережа"
 ],
 "Ethernet MAC": [
  null,
  "MAC Ethernet"
 ],
 "Ethernet MTU": [
  null,
  "MTU Ethernet"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Приклад: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Приклад: 88,2019,nfs,rsync"
 ],
 "Excellent password": [
  null,
  "Чудовий пароль"
 ],
 "Expansion chassis": [
  null,
  "Апаратний блок розширення"
 ],
 "Failed": [
  null,
  "Помилка"
 ],
 "Failed to add port": [
  null,
  "Не вдалося додати порт"
 ],
 "Failed to add service": [
  null,
  "Не вдалося додати службу"
 ],
 "Failed to add zone": [
  null,
  "Не вдалося додати зону"
 ],
 "Failed to change password": [
  null,
  "Не вдалося змінити пароль"
 ],
 "Failed to edit service": [
  null,
  "Не вдалося змінити службу"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Не вдалося увімкнути $0 у firewalld"
 ],
 "Failed to save settings": [
  null,
  "Не вдалося зберегти параметри"
 ],
 "Filter services": [
  null,
  "Фільтрувати служби"
 ],
 "Firewall": [
  null,
  "Брандмауер"
 ],
 "Firewall is not available": [
  null,
  "Брандмауер недоступний"
 ],
 "Forward delay $forward_delay": [
  null,
  "Затримка переспрямування $forward_delay"
 ],
 "Gateway": [
  null,
  "Шлюз"
 ],
 "Gateway $gateway": [
  null,
  "Шлюз $gateway"
 ],
 "General": [
  null,
  "Загальний"
 ],
 "Generated": [
  null,
  "Створений"
 ],
 "Go to now": [
  null,
  "Перейти зараз"
 ],
 "Group": [
  null,
  "Група"
 ],
 "Hair pin mode": [
  null,
  "Режим початкової зони"
 ],
 "Hairpin mode": [
  null,
  "Режим початкової зони (hairpin)"
 ],
 "Handheld": [
  null,
  "Кишеньковий пристрій"
 ],
 "Hello time $hello_time": [
  null,
  "Час вітання $hello_time"
 ],
 "Hide confirmation password": [
  null,
  "Приховати підтвердження пароля"
 ],
 "Hide password": [
  null,
  "Приховати пароль"
 ],
 "Host key is incorrect": [
  null,
  "Ключ вузла є неправильним"
 ],
 "ID": [
  null,
  "Ід."
 ],
 "ID $id": [
  null,
  "Ід. $id"
 ],
 "IP address": [
  null,
  "IP-адреса"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP-адреса із префіксом маршрутизації. Записи значень слід відокремлювати комами. Приклад: 192.0.2.0/24, 2001:db8::/32"
 ],
 "IP addresses": [
  null,
  "IP-адреси"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 settings": [
  null,
  "Параметри IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "Параметри IPv6"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Якщо не заповнювати, ідентифікатор буде створено на основі пов'язаних служб портів та номерів портів"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Якщо відбиток є відповідним, натисніть «Довіряти і додати вузол». Якщо ж це не так, не встановлюйте з'єднання і повідомте про подію адміністратору."
 ],
 "Ignore": [
  null,
  "Ігнорувати"
 ],
 "Inactive": [
  null,
  "Неактивний"
 ],
 "Included services": [
  null,
  "Включені служби"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Типово, вхідні запити заблоковано. Вихідні запити не заблоковано."
 ],
 "Install": [
  null,
  "Встановити"
 ],
 "Install software": [
  null,
  "Встановити програмне забезпечення"
 ],
 "Installing $0": [
  null,
  "Встановлюємо $0"
 ],
 "Interface": [
  null,
  "Інтерфейс",
  "Інтерфейси",
  "Інтерфейси"
 ],
 "Interface members": [
  null,
  "Учасники інтерфейсу"
 ],
 "Interfaces": [
  null,
  "Інтерфейси"
 ],
 "Internal error": [
  null,
  "Внутрішня помилка"
 ],
 "Invalid DNS address: $0": [
  null,
  "Некоректна адреса DNS: $0"
 ],
 "Invalid IP address '$0'": [
  null,
  "Некоректна IP-адреса «$0»"
 ],
 "Invalid IP address: $0": [
  null,
  "Некоректна IP-адреса: $0"
 ],
 "Invalid address $0": [
  null,
  "Некоректна адреса $0"
 ],
 "Invalid date format": [
  null,
  "Некоректний формат дати"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Некоректний формат дати і часу"
 ],
 "Invalid destination address: $0": [
  null,
  "Некоректна адреса призначення: $0"
 ],
 "Invalid file permissions": [
  null,
  "Некоректні права доступу до файла"
 ],
 "Invalid gateway address: $0": [
  null,
  "Некоректна адреса шлюзу: $0"
 ],
 "Invalid metric $0": [
  null,
  "Некоректна метрика $0"
 ],
 "Invalid port number": [
  null,
  "Некоректний номер порту"
 ],
 "Invalid prefix $0": [
  null,
  "Некоректний префікс $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Некоректний префікс або маска мережі $0"
 ],
 "Invalid range": [
  null,
  "Некоректний діапазон"
 ],
 "Invalid time format": [
  null,
  "Некоректний формат визначення часу"
 ],
 "Invalid timezone": [
  null,
  "Некоректний часовий пояс"
 ],
 "IoT gateway": [
  null,
  "Шлюз IoT"
 ],
 "Keep connection": [
  null,
  "Підтримувати з’єднання"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Key password": [
  null,
  "Пароль до ключа"
 ],
 "LACP key": [
  null,
  "Ключ LACP"
 ],
 "Laptop": [
  null,
  "Переносний ПК"
 ],
 "Learn more": [
  null,
  "Докладніше"
 ],
 "Link down delay": [
  null,
  "Затримка розірвання зв’язку"
 ],
 "Link local": [
  null,
  "Пов’язати локальний"
 ],
 "Link monitoring": [
  null,
  "Спостереження за зв’язком"
 ],
 "Link up delay": [
  null,
  "Затримка встановлення зв’язку"
 ],
 "Link watch": [
  null,
  "Спостереження за посиланнями"
 ],
 "Listen port": [
  null,
  "Порт очікування"
 ],
 "Listen port must be a number": [
  null,
  "Порт очікування має бути числом"
 ],
 "Load balancing": [
  null,
  "Збалансовування навантаження"
 ],
 "Loading system modifications...": [
  null,
  "Завантажуємо модифікації системи…"
 ],
 "Log in": [
  null,
  "Увійти"
 ],
 "Log in to $0": [
  null,
  "Увійти до $0"
 ],
 "Log messages": [
  null,
  "Повідомлення журналу"
 ],
 "Login failed": [
  null,
  "Невдала спроба увійти"
 ],
 "Low profile desktop": [
  null,
  "Низькопрофільна робоча станція"
 ],
 "Lunch box": [
  null,
  "Пусковий комп'ютер"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (рекомендоване)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU має бути додатнім числом"
 ],
 "Main server chassis": [
  null,
  "Апаратний блок основного сервера"
 ],
 "Manage storage": [
  null,
  "Керування сховищем"
 ],
 "Managed interfaces": [
  null,
  "Керовані інтерфейси"
 ],
 "Manual": [
  null,
  "Вручну"
 ],
 "Manually": [
  null,
  "Вручну"
 ],
 "Maximum message age $max_age": [
  null,
  "Максимальний вік повідомлення $max_age"
 ],
 "Message to logged in users": [
  null,
  "Повідомлення користувачам, які увійшли"
 ],
 "Metric": [
  null,
  "Метрика"
 ],
 "Mini PC": [
  null,
  "Міні-ПК"
 ],
 "Mini tower": [
  null,
  "Міні-башточка"
 ],
 "Mode": [
  null,
  "Режим"
 ],
 "Monitoring interval": [
  null,
  "Інтервал оновлення"
 ],
 "Monitoring targets": [
  null,
  "Спостерігаємо за цілями"
 ],
 "Multi-system chassis": [
  null,
  "Багатосистемний апаратний блок"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Можна вказати декілька адрес, відокремивши їх комами або пробілами."
 ],
 "NSNA ping": [
  null,
  "Луна-імпульс NSNA"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Name": [
  null,
  "Назва"
 ],
 "Need at least one NTP server": [
  null,
  "Потрібен принаймні один сервер NTP"
 ],
 "Network bond": [
  null,
  "Мережевий зв'язок"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Для отримання списку пристроїв мережі та графіків слід встановити NetworkManager"
 ],
 "Network logs": [
  null,
  "Журнали роботи у мережі"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager не встановлено"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager не запущено"
 ],
 "Networking": [
  null,
  "Робота у мережі"
 ],
 "New password was not accepted": [
  null,
  "Новий пароль не прийнято"
 ],
 "No": [
  null,
  "Ні"
 ],
 "No carrier": [
  null,
  "Немає сигналу"
 ],
 "No delay": [
  null,
  "Без затримки"
 ],
 "No description available": [
  null,
  "Немає опису"
 ],
 "No peers added.": [
  null,
  "Не додано жодного вузла."
 ],
 "No results found": [
  null,
  "Нічого не знайдено"
 ],
 "No such file or directory": [
  null,
  "Немає такого файла або каталогу"
 ],
 "No system modifications": [
  null,
  "Немає модифікацій системи"
 ],
 "None": [
  null,
  "Немає"
 ],
 "Not a valid private key": [
  null,
  "Некоректний закритий ключ"
 ],
 "Not authorized to disable the firewall": [
  null,
  "Не уповноважено вимикати брандмауер"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Не уповноважено вмикати брандмауер"
 ],
 "Not available": [
  null,
  "Недоступний"
 ],
 "Not permitted to configure network devices": [
  null,
  "Не дозволено налаштовувати пристрої мережі"
 ],
 "Not permitted to perform this action.": [
  null,
  "Немає дозволу на виконання цієї дії."
 ],
 "Not synchronized": [
  null,
  "Не синхронізовано"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Occurrences": [
  null,
  "Випадки"
 ],
 "Ok": [
  null,
  "Гаразд"
 ],
 "Old password not accepted": [
  null,
  "Старий пароль не прийнято"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Після встановлення Cockpit його можна увімкнути за допомогою команди «systemctl enable --now cockpit.socket»."
 ],
 "Options": [
  null,
  "Параметри"
 ],
 "Other": [
  null,
  "Інше"
 ],
 "PackageKit crashed": [
  null,
  "Аварійне завершення роботи PackageKit"
 ],
 "Parent": [
  null,
  "Батьківський"
 ],
 "Parent $parent": [
  null,
  "Батьківський $parent"
 ],
 "Part of $0": [
  null,
  "Є частиною $0"
 ],
 "Passive": [
  null,
  "Неактивний"
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Password is not acceptable": [
  null,
  "Пароль є неприйнятним"
 ],
 "Password is too weak": [
  null,
  "Пароль є надто простим"
 ],
 "Password not accepted": [
  null,
  "Пароль не прийнято"
 ],
 "Paste": [
  null,
  "Вставити"
 ],
 "Paste error": [
  null,
  "Помилка вставлення"
 ],
 "Paste existing key": [
  null,
  "Вставити наявний ключ"
 ],
 "Path cost": [
  null,
  "Вартість маршруту"
 ],
 "Path cost $path_cost": [
  null,
  "Вартість шляху $path_cost"
 ],
 "Path to file": [
  null,
  "Шлях до файла"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "У вузла #$0 некоректний порт кінцевої точки. Порт має бути числом."
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820, [2001:db8::1]:51820 or example.com:51820": [
  null,
  "У вузла #$0 некоректна кінцева точка. Її слід вказати у форматі вузол:порт, приклад: 1.2.3.4:51820, [2001:db8::1]:51820 або example.com:51820"
 ],
 "Peers": [
  null,
  "Вузли"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Вузли є іншими машинами, які з'єднано із цією. Відкриті ключі з інших машин буде надано у спільне користування цій машині."
 ],
 "Peripheral chassis": [
  null,
  "Периферійний апаратний блок"
 ],
 "Permanent": [
  null,
  "Постійний"
 ],
 "Pick date": [
  null,
  "Вибрати дату"
 ],
 "Ping interval": [
  null,
  "Проміжок між імпульсами"
 ],
 "Ping target": [
  null,
  "Ціль тестування луною"
 ],
 "Pizza box": [
  null,
  "З коробку для піци"
 ],
 "Please install the $0 package": [
  null,
  "Будь ласка, встановіть пакунок $0"
 ],
 "Portable": [
  null,
  "Портативний"
 ],
 "Ports": [
  null,
  "Порти"
 ],
 "Prefix length": [
  null,
  "Довжина префікса"
 ],
 "Prefix length or netmask": [
  null,
  "Довжина префікса або маска мережі"
 ],
 "Preparing": [
  null,
  "Приготування"
 ],
 "Present": [
  null,
  "Поточна"
 ],
 "Preserve": [
  null,
  "Зберегти"
 ],
 "Primary": [
  null,
  "Основний"
 ],
 "Priority": [
  null,
  "Пріоритетність"
 ],
 "Priority $priority": [
  null,
  "Пріоритетність $priority"
 ],
 "Private key": [
  null,
  "Закритий ключ"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Час очікування відповіді на запит за допомогою ssh-add вичерпано"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Час очікування відповіді на запит за допомогою ssh-keygen вичерпано"
 ],
 "Public key": [
  null,
  "Відкритий ключ"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Відкритий ключ буде створено, коли буде введено коректний закритий ключ"
 ],
 "RAID chassis": [
  null,
  "Апаратний блок RAID"
 ],
 "Rack mount chassis": [
  null,
  "Апаратний блок монтування стійок"
 ],
 "Random": [
  null,
  "Випадковий"
 ],
 "Range": [
  null,
  "Діапазон"
 ],
 "Range must be strictly ordered": [
  null,
  "Діапазон має бути строго упорядковано"
 ],
 "Reboot": [
  null,
  "Перезавантажити"
 ],
 "Receiving": [
  null,
  "Отримання"
 ],
 "Regenerate": [
  null,
  "Повторно створити"
 ],
 "Removals:": [
  null,
  "Вилучення:"
 ],
 "Remove $0": [
  null,
  "Вилучити $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Вилучити службу $0 із зони $1"
 ],
 "Remove item": [
  null,
  "Вилучити запис"
 ],
 "Remove service $0": [
  null,
  "Вилучити службу $0"
 ],
 "Remove zone $0": [
  null,
  "Вилучити зону $0"
 ],
 "Removing $0": [
  null,
  "Вилучаємо $0"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Вилучення $0 призведе до розірвання з’єднання із сервером і зробить адміністративний інтерфейс користувача недоступним."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Вилучення служби cockpit може призвести до недоступності вебконсолі. Переконайтеся, що застосування цієї зони не поширюється на ваше поточне з'єднання за допомогою вебконсолі."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Вилучення запису зони призведе до вилучення усіх служб у ній."
 ],
 "Restoring connection": [
  null,
  "Відновлюємо з’єднання"
 ],
 "Round robin": [
  null,
  "Циклічне"
 ],
 "Routes": [
  null,
  "Маршрути"
 ],
 "Row expansion": [
  null,
  "Розгортання рядка"
 ],
 "Row select": [
  null,
  "Вибір рядка"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Запустити цю команду довіреною мережею або фізично на віддаленому комп'ютері:"
 ],
 "Runner": [
  null,
  "Засіб для запуску"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Ключ SSH"
 ],
 "SSH key login": [
  null,
  "Вхід за ключем SSH"
 ],
 "STP forward delay": [
  null,
  "Затримка переспрямування STP"
 ],
 "STP hello time": [
  null,
  "Час вітання STP"
 ],
 "STP maximum message age": [
  null,
  "Максимальний вік повідомлення STP"
 ],
 "STP priority": [
  null,
  "Пріоритет STP"
 ],
 "Save": [
  null,
  "Зберегти"
 ],
 "Sealed-case PC": [
  null,
  "ПК з опломбованим корпусом"
 ],
 "Search domain": [
  null,
  "Домен пошуку"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Налаштування Security Enhanced Linux та усування вад"
 ],
 "Select an option": [
  null,
  "Виберіть варіант"
 ],
 "Select method": [
  null,
  "Виберіть метод"
 ],
 "Sending": [
  null,
  "Надсилання"
 ],
 "Server": [
  null,
  "Сервер"
 ],
 "Server has closed the connection.": [
  null,
  "З’єднання розірвано сервером."
 ],
 "Service": [
  null,
  "Служба"
 ],
 "Services": [
  null,
  "Служби"
 ],
 "Set time": [
  null,
  "Встановити час"
 ],
 "Set to": [
  null,
  "Встановити значення"
 ],
 "Shared": [
  null,
  "Спільний"
 ],
 "Shell script": [
  null,
  "Скрипт оболонки"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Показати підтвердження пароля"
 ],
 "Show password": [
  null,
  "Показати пароль"
 ],
 "Shut down": [
  null,
  "Вимкнути"
 ],
 "Single rank": [
  null,
  "Єдиний ранг"
 ],
 "Sorted from least to most trusted": [
  null,
  "Упорядковано від найменшої до найбільшої довіри"
 ],
 "Space-saving computer": [
  null,
  "Компактний комп'ютер"
 ],
 "Spanning tree protocol": [
  null,
  "Протокол пересування ієрархією"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Протокол пересування ієрархією (STP)"
 ],
 "Specific time": [
  null,
  "У визначений час"
 ],
 "Stable": [
  null,
  "Стабільний"
 ],
 "Start service": [
  null,
  "Запустити службу"
 ],
 "Status": [
  null,
  "Стан"
 ],
 "Stick PC": [
  null,
  "Паличковий ПК"
 ],
 "Sticky": [
  null,
  "Липкий"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "Strong password": [
  null,
  "Складний пароль"
 ],
 "Sub-Chassis": [
  null,
  "Підблок"
 ],
 "Sub-Notebook": [
  null,
  "Підноутбук"
 ],
 "Switch off $0": [
  null,
  "Вимкнути $0"
 ],
 "Switch on $0": [
  null,
  "Увімкнути $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Вимикання $0 призведе до розірвання з’єднання із сервером і зробить адміністративний інтерфейс користувача недоступним."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Вмикання $0 призведе до розірвання з’єднання із сервером і зробить адміністративний інтерфейс користувача недоступним."
 ],
 "Synchronized": [
  null,
  "Синхронізовано"
 ],
 "Synchronized with $0": [
  null,
  "Синхронізовано із $0"
 ],
 "Synchronizing": [
  null,
  "Синхронізація"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tablet": [
  null,
  "Планшет"
 ],
 "Team": [
  null,
  "Команда"
 ],
 "Team port": [
  null,
  "Порт команди"
 ],
 "Team port settings": [
  null,
  "Параметри порту команди"
 ],
 "Testing connection": [
  null,
  "Перевіряємо з’єднання"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Ключ SSH $0 $1 на $2 буде додано до файла $3 $4 на $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Ключ SSH $0 буде доступним протягом решти сеансу і також буде доступним для входу на інші вузли."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Ключ SSH для входу до $0 захищено паролем, а на вузлі заборонено вхід без пароля. Буль ласка, вкажіть пароль до ключа у $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Ключ SSH для входу до $0 захищено. Ви можете увійти або за допомогою пароль до вашого облікового запису або вказавши пароль до ключа у $1."
 ],
 "The cockpit service is automatically included": [
  null,
  "Службу cockpit включено автоматично"
 ],
 "The fingerprint should match:": [
  null,
  "Відбиток має збігатися:"
 ],
 "The key password can not be empty": [
  null,
  "Пароль до ключа не може бути порожнім"
 ],
 "The key passwords do not match": [
  null,
  "Паролі до ключа не збігаються"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Користувач, який увійшов до системи, не має права переглядати модифікації системи"
 ],
 "The password can not be empty": [
  null,
  "Пароль не може бути порожнім"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Відбиток-результат можна поширювати у спосіб із загальним доступом, зокрема електронною поштою."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Відбиток-результат можна поширювати відкритими способами, включно із електронною поштою. Якщо ви просите когось виконати перевірку для вас, вони можуть надсилати результати за допомогою будь-якого способу."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Сервер відмовився розпізнавати користувача за допомогою будь-якого з підтримуваних методів."
 ],
 "There are no active services in this zone": [
  null,
  "У цій зоні немає активних служб"
 ],
 "This device cannot be managed here.": [
  null,
  "Тут не можна керувати цим пристроєм."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Цей інструмент налаштовує правила SELinux і може допомогти зрозуміти та усунути порушення правил."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Цей інструмент налаштовує систему на запис дампів аварій ядра. Передбачено підтримку призначень дампу «local» (диск), «ssh» та «nfs»."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Цей інструмент створюдє архів даних щодо налаштувань та діагностики для запущеної системи. Архів може бути збережено локально або централізовано з метою журналювання або стеження або надіслано до представників технічної підтримки, розробників або адміністраторів системи, щоб допомогти з пошуком технічних проблем та діагностикою."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Цей інструмент керує локальним сховищем даних, зокрема файловими системами, групами томів LVM2 та монтуваннями NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Цей інструмент керує можливостями роботи у мережі, зокрема зв'язками, містками, командами, віртуальними LAN та брандмауерами, за допомогою NetworkManager і Firewalld. NetworkManager є несумісним із типовим для Ubuntu systemd-networkd та скриптами ifupdown Debian."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "У цій зоні міститься служба cockpit. Переконайтеся, що застосування цієї зони не поширюється на ваше поточне з'єднання за допомогою вебконсолі."
 ],
 "Time zone": [
  null,
  "Часовий пояс"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Щоб переконатися, що дані вашого з'єднання не буде перехоплено зловмисниками, будь ласка, підтвердьте відбиток ключа вузла:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Щоб перевірити відбиток, віддайте вказану нижче команду для $0 під час безпосередньої роботи на комп'ютері або з використанням надійної мережі:"
 ],
 "Toggle date picker": [
  null,
  "Перемкнути засіб вибору дати"
 ],
 "Too much data": [
  null,
  "Забагато даних"
 ],
 "Total size: $0": [
  null,
  "Загальний розмір: $0"
 ],
 "Tower": [
  null,
  "Башточка"
 ],
 "Transmitting": [
  null,
  "Передавання"
 ],
 "Troubleshoot…": [
  null,
  "Діагностика проблем…"
 ],
 "Trust and add host": [
  null,
  "Довіряти і додати вузол"
 ],
 "Trust level": [
  null,
  "Рівень довіри"
 ],
 "Trying to synchronize with $0": [
  null,
  "Намагаємося синхронізуватися з $0"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Не вдалося увійти до $0 за допомогою розпізнавання за ключем SSH. Будь ласка, вкажіть пароль."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Не вдалося увійти до $0. Вузол не приймає входу за паролем або будь-яким з ваших ключів SSH."
 ],
 "Unexpected error": [
  null,
  "Неочікувана помилка"
 ],
 "Unknown": [
  null,
  "Невідомий"
 ],
 "Unknown \"$0\"": [
  null,
  "Невідомий «$0»"
 ],
 "Unknown configuration": [
  null,
  "Невідомі налаштування"
 ],
 "Unknown host: $0": [
  null,
  "Невідомий вузол: $0"
 ],
 "Unknown service name": [
  null,
  "Невідома назва служби"
 ],
 "Unmanaged interfaces": [
  null,
  "Некеровані інтерфейси"
 ],
 "Untrusted host": [
  null,
  "Ненадійний вузол"
 ],
 "Use $0": [
  null,
  "Використати $0"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "Ід. VLAN"
 ],
 "Verify fingerprint": [
  null,
  "Перевірити відбиток"
 ],
 "View all logs": [
  null,
  "Переглянути усі журнали"
 ],
 "View automation script": [
  null,
  "Переглянути скрипт автоматизації"
 ],
 "Visit firewall": [
  null,
  "Відвідати брандмауер"
 ],
 "Waiting": [
  null,
  "Очікування"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Очікуємо на завершення інших дій із програмним забезпеченням"
 ],
 "Weak password": [
  null,
  "Простий пароль"
 ],
 "Web Console for Linux servers": [
  null,
  "Вебконсоль для серверів під керуванням Linux"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Буде встановлено значення «Автоматично»"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "Так"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Ви вперше встановлюєте з'єднання із $0."
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Вас не уповноважено на внесення змін до брандмауера."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "У вашій програмі для перегляду не передбачено можливості вставлення з контекстного меню. Ви можете скористатися для вставлення комбінацією Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Ваш сеанс перервано."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Строк роботи у вашому сеансі вичерпано. Будь ласка, увійдіть до системи ще раз."
 ],
 "Zone": [
  null,
  "Зона"
 ],
 "[binary data]": [
  null,
  "[двійкові дані]"
 ],
 "[no data]": [
  null,
  "[немає даних]"
 ],
 "edit": [
  null,
  "редагувати"
 ],
 "in less than a minute": [
  null,
  "за менше, ніж хвилину"
 ],
 "less than a minute ago": [
  null,
  "менш, ніж хвилину тому"
 ],
 "password quality": [
  null,
  "якість пароля"
 ],
 "show less": [
  null,
  "показати менше"
 ],
 "show more": [
  null,
  "показати більше"
 ],
 "wireguard-tools package is not installed": [
  null,
  "Не встановлено пакунок wireguard-tools"
 ]
});
