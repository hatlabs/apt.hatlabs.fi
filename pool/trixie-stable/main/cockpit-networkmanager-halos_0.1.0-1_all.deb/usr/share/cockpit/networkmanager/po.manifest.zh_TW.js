cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "診斷報告"
 ],
 "Kernel dump": [
  null,
  "核心傾印"
 ],
 "Managing VLANs": [
  null,
  "管理 VLAN"
 ],
 "Managing firewall": [
  null,
  "防火牆管理"
 ],
 "Managing networking bonds": [
  null,
  "管理網路 bond"
 ],
 "Managing networking bridges": [
  null,
  "管理網路橋接"
 ],
 "Managing networking teams": [
  null,
  "管理網路 team"
 ],
 "Networking": [
  null,
  "網路"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "服務"
 ],
 "Storage": [
  null,
  "儲存裝置"
 ],
 "bond": [
  null,
  "bond"
 ],
 "bridge": [
  null,
  "橋接"
 ],
 "firewall": [
  null,
  "防火牆"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "介面"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "網路"
 ],
 "port": [
  null,
  "連接埠"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "team"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "區域"
 ]
});
