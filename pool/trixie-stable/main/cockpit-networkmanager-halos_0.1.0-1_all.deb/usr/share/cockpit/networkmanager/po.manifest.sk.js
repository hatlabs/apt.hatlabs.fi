cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "sk",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnostické hlásenia"
 ],
 "Kernel dump": [
  null,
  "Výpis pamäti jadra"
 ],
 "Managing VLANs": [
  null,
  "Správa VLAN sietí"
 ],
 "Managing firewall": [
  null,
  "Správa brány firewall"
 ],
 "Managing networking bonds": [
  null,
  "Správa sieťových spojení (bond)"
 ],
 "Managing networking bridges": [
  null,
  "Správa sieťových mostov"
 ],
 "Managing networking teams": [
  null,
  "Správa sieťového teamingu"
 ],
 "Networking": [
  null,
  "Sieť"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Služby"
 ],
 "Storage": [
  null,
  "Úložisko"
 ],
 "bond": [
  null,
  "spojenie (bond)"
 ],
 "bridge": [
  null,
  "most"
 ],
 "firewall": [
  null,
  "firewall"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "rozhranie"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "sieť"
 ],
 "port": [
  null,
  "port"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "teaming"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "zóna"
 ]
});
