cockpit.locale({
 "": {
  "plural-forms": (n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "pl",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 active zone": [
  null,
  "$0 aktywna strefa",
  "$0 aktywne strefy",
  "$0 aktywnych stref"
 ],
 "$0 day": [
  null,
  "$0 dzień",
  "$0 dni",
  "$0 dni"
 ],
 "$0 exited with code $1": [
  null,
  "$0 zakończyło działanie z kodem $1"
 ],
 "$0 failed": [
  null,
  "$0 się nie powiodło"
 ],
 "$0 hour": [
  null,
  "$0 godzina",
  "$0 godziny",
  "$0 godzin"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 nie jest dostępne w żadnym repozytorium."
 ],
 "$0 key changed": [
  null,
  "Zmieniono klucz $0"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 zostało zakończone z sygnałem $1"
 ],
 "$0 minute": [
  null,
  "$0 minuta",
  "$0 minuty",
  "$0 minut"
 ],
 "$0 month": [
  null,
  "$0 miesiąc",
  "$0 miesiące",
  "$0 miesięcy"
 ],
 "$0 week": [
  null,
  "$0 tydzień",
  "$0 tygodnie",
  "$0 tygodni"
 ],
 "$0 will be installed.": [
  null,
  "$0 zostanie zainstalowane."
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 lata",
  "$0 lat"
 ],
 "$0 zone": [
  null,
  "Strefa $0"
 ],
 "1 day": [
  null,
  "1 dzień"
 ],
 "1 hour": [
  null,
  "1 godzina"
 ],
 "1 minute": [
  null,
  "1 minuta"
 ],
 "1 week": [
  null,
  "1 tydzień"
 ],
 "20 minutes": [
  null,
  "20 minut"
 ],
 "40 minutes": [
  null,
  "40 minut"
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "6 hours": [
  null,
  "6 godzin"
 ],
 "60 minutes": [
  null,
  "Godzina"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "LACP 802.3ad"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Na $0 nie zainstalowano zgodnej wersji Cockpit."
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Wiązanie sieciowe łączy wiele interfejsów sieciowych w jeden interfejs logiczny o wyższej przepustowości lub redundancji."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Nowy klucz SSH w $0 zostanie utworzony dla użytkownika $1 na komputerze $2 i zostanie dodany do pliku $3 użytkownika $4 na komputerze $5."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "Monitorowanie ARP"
 ],
 "ARP ping": [
  null,
  "Ping ARP"
 ],
 "Absent": [
  null,
  "Nieobecne"
 ],
 "Actions": [
  null,
  "Działania"
 ],
 "Active": [
  null,
  "Aktywne"
 ],
 "Active backup": [
  null,
  "Aktywna kopia zapasowa"
 ],
 "Adaptive load balancing": [
  null,
  "Adaptacyjne równoważenie obciążenia"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Adaptacyjne równoważenie obciążenia przesyłu"
 ],
 "Add": [
  null,
  "Dodaj"
 ],
 "Add $0": [
  null,
  "Dodaj $0"
 ],
 "Add DNS server": [
  null,
  "Dodaj serwer DNS"
 ],
 "Add VLAN": [
  null,
  "Dodaj VLAN"
 ],
 "Add VPN": [
  null,
  "Dodaj VPN"
 ],
 "Add WireGuard VPN": [
  null,
  "Dodaj VPN WireGuard"
 ],
 "Add a new zone": [
  null,
  "Dodaj nową strefę"
 ],
 "Add address": [
  null,
  "Dodaj adres"
 ],
 "Add bond": [
  null,
  "Dodaj wiązanie"
 ],
 "Add bridge": [
  null,
  "Dodaj mostek"
 ],
 "Add member": [
  null,
  "Dodaj element"
 ],
 "Add new zone": [
  null,
  "Dodaj nową strefę"
 ],
 "Add peer": [
  null,
  "Dodaj partnera"
 ],
 "Add ports": [
  null,
  "Dodaj porty"
 ],
 "Add ports to $0 zone": [
  null,
  "Dodaj porty do strefy $0"
 ],
 "Add route": [
  null,
  "Dodaj trasę"
 ],
 "Add search domain": [
  null,
  "Dodaj domenę wyszukiwania"
 ],
 "Add services": [
  null,
  "Dodaj usługi"
 ],
 "Add services to $0 zone": [
  null,
  "Dodaj usługi do strefy $0"
 ],
 "Add services to zone $0": [
  null,
  "Dodaj usługi do strefy $0"
 ],
 "Add team": [
  null,
  "Dodaj zespół"
 ],
 "Add zone": [
  null,
  "Dodaj strefę"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Dodanie $0 zerwie połączenie z serwerem i uniemożliwi korzystanie z interfejsu administracji."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Dodanie niestandardowych portów spowoduje ponowne wczytanie zapory sieciowej. Ponowne wczytanie spowoduje utratę całej konfiguracji tylko dla obecnej sesji."
 ],
 "Additional DNS $val": [
  null,
  "Dodatkowy DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Dodatkowe domeny wyszukiwania DNS $val"
 ],
 "Additional address $val": [
  null,
  "Dodatkowy adres $val"
 ],
 "Additional packages:": [
  null,
  "Dodatkowe pakiety:"
 ],
 "Additional ports": [
  null,
  "Dodatkowe porty"
 ],
 "Address": [
  null,
  "Adres"
 ],
 "Address $val": [
  null,
  "Adres $val"
 ],
 "Addresses": [
  null,
  "Adresy"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Adresy są niewłaściwie sformatowane"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administracja za pomocą konsoli internetowej Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Zaawansowane TCA"
 ],
 "All-in-one": [
  null,
  "Wszystko w jednym"
 ],
 "Allowed IPs": [
  null,
  "Dozwolone adresy IP"
 ],
 "Allowed addresses": [
  null,
  "Dozwolone adresy"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentacja ról Ansible"
 ],
 "Authenticating": [
  null,
  "Uwierzytelnianie"
 ],
 "Authentication": [
  null,
  "Uwierzytelnienie"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Wymagane jest uwierzytelnienie, aby wykonać zadania wymagające uprawnień za pomocą konsoli internetowej Cockpit"
 ],
 "Authorize SSH key": [
  null,
  "Upoważnij klucz SSH"
 ],
 "Automatic": [
  null,
  "Automatyczne"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automatyczne (tylko DHCP)"
 ],
 "Automatically using NTP": [
  null,
  "Automatycznie za pomocą NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatycznie za pomocą dodatkowych serwerów NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatycznie za pomocą podanych serwerów NTP"
 ],
 "Automation script": [
  null,
  "Skrypt automatyzacji"
 ],
 "Balancer": [
  null,
  "Równoważenie"
 ],
 "Blade": [
  null,
  "Kasetowy"
 ],
 "Blade enclosure": [
  null,
  "Obudowa kasetowa"
 ],
 "Bond": [
  null,
  "Wiązanie"
 ],
 "Bridge": [
  null,
  "Mostek"
 ],
 "Bridge port": [
  null,
  "Port mostku"
 ],
 "Bridge port settings": [
  null,
  "Ustawienia portu mostku"
 ],
 "Broadcast": [
  null,
  "Broadcast"
 ],
 "Broken configuration": [
  null,
  "Uszkodzona konfiguracja"
 ],
 "Bus expansion chassis": [
  null,
  "Obudowa rozszerzenia magistrali"
 ],
 "Cancel": [
  null,
  "Anuluj"
 ],
 "Cannot forward login credentials": [
  null,
  "Nie można przekazać danych uwierzytelniania logowania"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nie można planować zdarzeń w przeszłości"
 ],
 "Carrier": [
  null,
  "Operator"
 ],
 "Change": [
  null,
  "Zmień"
 ],
 "Change system time": [
  null,
  "Zmień czas systemu"
 ],
 "Change the settings": [
  null,
  "Zmień ustawienia"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Zmienione klucze są często wynikiem przeinstalowania systemu operacyjnego. Nieoczekiwana zmiana może jednak wskazywać na próbę przechwycenia połączenia przez stronę trzecią."
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Zmiana ustawień zerwie połączenie z serwerem i uniemożliwi korzystanie z interfejsu administracji."
 ],
 "Checking IP": [
  null,
  "Sprawdzanie IP"
 ],
 "Checking installed software": [
  null,
  "Sprawdzanie zainstalowanego oprogramowania"
 ],
 "Close": [
  null,
  "Zamknij"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Konfiguracja usług NetworkManager i firewalld w programie Cockpit"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit nie może skontaktować się z podanym komputerem."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit to menedżer serwerów ułatwiający administrowanie serwerów Linux przez przeglądarkę WWW. Można z łatwością przechodzić między terminalem a narzędziami WWW. Usługa uruchomiona za pomocą Cockpit może zostać zatrzymana za pomocą terminala. Jeśli błąd wystąpi w terminalu, to można go zobaczyć w interfejsie dziennika Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit nie jest zgodny z oprogramowaniem w systemie."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit nie jest zainstalowany"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit nie jest zainstalowany w systemie."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit jest idealny dla nowych administratorów, umożliwiając łatwe wykonywanie prostych zadań, takich jak administracja urządzeniami do przechowywania danych, badanie dzienników oraz uruchamianie i zatrzymywanie usług. Można monitorować i administrować wiele serwerów w tym samym czasie. Wystarczy dodać je pojedynczym kliknięciem."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Zbieranie i pakowanie danych diagnostycznych i wsparcia"
 ],
 "Collect kernel crash dumps": [
  null,
  "Zbieranie zrzutów awarii jądra"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Przyjmowane są porty, zakresy i usługi oddzielone przecinkami"
 ],
 "Compact PCI": [
  null,
  "Kompaktowe PCI"
 ],
 "Configuring": [
  null,
  "Konfigurowanie"
 ],
 "Configuring IP": [
  null,
  "Konfigurowanie IP"
 ],
 "Confirm key password": [
  null,
  "Potwierdź hasło klucza"
 ],
 "Confirm removal of $0": [
  null,
  "Potwierdź usunięcie $0"
 ],
 "Connect automatically": [
  null,
  "Łączenie automatyczne"
 ],
 "Connection has timed out.": [
  null,
  "Połączenie przekroczyło czas oczekiwania."
 ],
 "Connection will be lost": [
  null,
  "Połączenie zostanie utracone"
 ],
 "Convertible": [
  null,
  "2 w jednym"
 ],
 "Copied": [
  null,
  "Skopiowano"
 ],
 "Copy": [
  null,
  "Skopiuj"
 ],
 "Copy to clipboard": [
  null,
  "Skopiuj do schowka"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Utwórz nowy klucz SSH i go upoważnij"
 ],
 "Create it": [
  null,
  "Utwórz"
 ],
 "Create new task file with this content.": [
  null,
  "Utwórz nowy plik zadania o tej treści."
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Utworzenie tej sieci $0 zerwie połączenie z serwerem i uniemożliwi korzystanie z interfejsu administracji."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Custom ports": [
  null,
  "Niestandardowe porty"
 ],
 "Custom zones": [
  null,
  "Niestandardowe strefy"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "Domeny wyszukiwania DNS"
 ],
 "DNS search domains $val": [
  null,
  "Domeny wyszukiwania DNS $val"
 ],
 "Deactivating": [
  null,
  "Dezaktywowanie"
 ],
 "Delay": [
  null,
  "Opóźnienie"
 ],
 "Delete": [
  null,
  "Usuń"
 ],
 "Delete $0": [
  null,
  "Usuń $0"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Usunięcie $0 zerwie połączenie z serwerem i uniemożliwi korzystanie z interfejsu administracji."
 ],
 "Description": [
  null,
  "Opis"
 ],
 "Desktop": [
  null,
  "Komputer stacjonarny"
 ],
 "Detachable": [
  null,
  "Odłączalny"
 ],
 "Diagnostic reports": [
  null,
  "Raporty diagnostyczne"
 ],
 "Disable the firewall": [
  null,
  "Wyłącz zaporę sieciową"
 ],
 "Disabled": [
  null,
  "Wyłączone"
 ],
 "Docking station": [
  null,
  "Stacja dokująca"
 ],
 "Downloading $0": [
  null,
  "Pobieranie $0"
 ],
 "Dual rank": [
  null,
  "Podwójny stopień"
 ],
 "Edit": [
  null,
  "Modyfikuj"
 ],
 "Edit VLAN settings": [
  null,
  "Modyfikuj ustawienia VLAN"
 ],
 "Edit WireGuard VPN": [
  null,
  "Modyfikuj VPN WireGuard"
 ],
 "Edit bond settings": [
  null,
  "Modyfikuj ustawienia wiązania"
 ],
 "Edit bridge settings": [
  null,
  "Modyfikuj ustawienia mostka"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Modyfikuj niestandardową usługę w strefie $0"
 ],
 "Edit rules and zones": [
  null,
  "Modyfikuj reguły i strefy"
 ],
 "Edit service": [
  null,
  "Modyfikuj usługę"
 ],
 "Edit service $0": [
  null,
  "Modyfikuj usługę $0"
 ],
 "Edit team settings": [
  null,
  "Modyfikuj ustawienia zespołu"
 ],
 "Embedded PC": [
  null,
  "Komputer osadzony"
 ],
 "Enable or disable the device": [
  null,
  "Włącz lub wyłącz urządzenie"
 ],
 "Enable service": [
  null,
  "Włącz usługę"
 ],
 "Enable the firewall": [
  null,
  "Włącz zaporę sieciową"
 ],
 "Enabled": [
  null,
  "Włączone"
 ],
 "Endpoint": [
  null,
  "Punkt końcowy"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "Punkt końcowy działający jako „serwer” musi zostać podany jako komputer:port, w przeciwnym razie można zostawić puste."
 ],
 "Enter a valid MAC address": [
  null,
  "Proszę podać prawidłowy adres MAC"
 ],
 "Entire subnet": [
  null,
  "Cała podsieć"
 ],
 "Ethernet MAC": [
  null,
  "MAC ethernetu"
 ],
 "Ethernet MTU": [
  null,
  "MTU ethernetu"
 ],
 "Ethtool": [
  null,
  "ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Przykład: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Przykład: 88,2019,nfs,rsync"
 ],
 "Excellent password": [
  null,
  "Doskonałe hasło"
 ],
 "Expansion chassis": [
  null,
  "Obudowa rozszerzenia"
 ],
 "Failed": [
  null,
  "Niepowodzenie"
 ],
 "Failed to add port": [
  null,
  "Dodanie portu się nie powiodło"
 ],
 "Failed to add service": [
  null,
  "Dodanie usługi się nie powiodło"
 ],
 "Failed to add zone": [
  null,
  "Dodanie strefy się nie powiodło"
 ],
 "Failed to change password": [
  null,
  "Zmiana hasła się nie powiodła"
 ],
 "Failed to edit service": [
  null,
  "Modyfikacja usługi się nie powiodła"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Włączenie $0 w usłudze firewalld się nie powiodło"
 ],
 "Failed to save settings": [
  null,
  "Zapisanie ustawień się nie powiodło"
 ],
 "Filter services": [
  null,
  "Filtrowanie usług"
 ],
 "Firewall": [
  null,
  "Zapora sieciowa"
 ],
 "Firewall is not available": [
  null,
  "Zapora sieciowa jest niedostępna"
 ],
 "Forward delay $forward_delay": [
  null,
  "Opóźnienie w przód $forward_delay"
 ],
 "Gateway": [
  null,
  "Brama"
 ],
 "General": [
  null,
  "Ogólne"
 ],
 "Generated": [
  null,
  "Utworzone"
 ],
 "Go to now": [
  null,
  "Przejdź teraz"
 ],
 "Group": [
  null,
  "Grupa"
 ],
 "Hair pin mode": [
  null,
  "Tryb Hairpin"
 ],
 "Hairpin mode": [
  null,
  "Tryb Hairpin"
 ],
 "Handheld": [
  null,
  "Przenośny"
 ],
 "Hello time $hello_time": [
  null,
  "Czas powitania $hello_time"
 ],
 "Host key is incorrect": [
  null,
  "Klucz komputera jest niepoprawny"
 ],
 "ID": [
  null,
  "Identyfikator"
 ],
 "ID $id": [
  null,
  "Identyfikator $id"
 ],
 "IP address": [
  null,
  "Adres IP"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "Adres IP z przedrostkiem trasowania. Wiele wartości należy oddzielić przecinkiem. Przykład: 192.0.2.0/24, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 settings": [
  null,
  "Ustawienia IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "Ustawienia IPv6"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Jeśli zostanie pozostawione puste, to identyfikator zostanie utworzony na podstawie powiązanych usług portu i numerów portów"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Jeśli odcisk się zgadza, należy kliknąć „Zaufaj i dodaj komputer”. W przeciwnym przypadku nie należy się łączyć i należy skontaktować się z administratorem."
 ],
 "Ignore": [
  null,
  "Ignorowanie"
 ],
 "Inactive": [
  null,
  "Nieaktywne"
 ],
 "Included services": [
  null,
  "Dołączone usługi"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Żądania przychodzące są domyślnie blokowane. Żądania wychodzące nie są blokowane."
 ],
 "Install": [
  null,
  "Zainstaluj"
 ],
 "Install software": [
  null,
  "Zainstaluj oprogramowanie"
 ],
 "Installing $0": [
  null,
  "Instalowanie $0"
 ],
 "Interface": [
  null,
  "Interfejs",
  "Interfejsy",
  "Interfejsy"
 ],
 "Interface members": [
  null,
  "Elementy interfejsu"
 ],
 "Interfaces": [
  null,
  "Interfejsy"
 ],
 "Internal error": [
  null,
  "Wewnętrzny błąd"
 ],
 "Invalid address $0": [
  null,
  "Nieprawidłowy adres $0"
 ],
 "Invalid date format": [
  null,
  "Nieprawidłowy format daty"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Nieprawidłowy format daty i nieprawidłowy format czasu"
 ],
 "Invalid file permissions": [
  null,
  "Nieprawidłowe uprawnienia pliku"
 ],
 "Invalid metric $0": [
  null,
  "Nieprawidłowe parametry $0"
 ],
 "Invalid port number": [
  null,
  "Nieprawidłowy numer portu"
 ],
 "Invalid prefix $0": [
  null,
  "Nieprawidłowy przedrostek $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Nieprawidłowy przedrostek lub maska sieci $0"
 ],
 "Invalid range": [
  null,
  "Nieprawidłowy zakres"
 ],
 "Invalid time format": [
  null,
  "Nieprawidłowy format czasu"
 ],
 "Invalid timezone": [
  null,
  "Nieprawidłowa strefa czasowa"
 ],
 "IoT gateway": [
  null,
  "Brama IoT"
 ],
 "Keep connection": [
  null,
  "Utrzymywanie połączenia"
 ],
 "Kernel dump": [
  null,
  "Zrzut jądra"
 ],
 "Key password": [
  null,
  "Hasło klucza"
 ],
 "LACP key": [
  null,
  "Klucz LACP"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Learn more": [
  null,
  "Więcej informacji"
 ],
 "Link down delay": [
  null,
  "Opóźnienie łącza w dół"
 ],
 "Link local": [
  null,
  "Link-local"
 ],
 "Link monitoring": [
  null,
  "Monitorowanie łącza"
 ],
 "Link up delay": [
  null,
  "Opóźnienie łącza w górę"
 ],
 "Link watch": [
  null,
  "Obserwacja łącza"
 ],
 "Listen port": [
  null,
  "Port nasłuchiwania"
 ],
 "Listen port must be a number": [
  null,
  "Port nasłuchiwania musi być liczbą"
 ],
 "Load balancing": [
  null,
  "Równoważenie obciążenia"
 ],
 "Loading system modifications...": [
  null,
  "Wczytywanie modyfikacji systemu…"
 ],
 "Log in": [
  null,
  "Zaloguj"
 ],
 "Log in to $0": [
  null,
  "Zaloguj się na $0"
 ],
 "Log messages": [
  null,
  "Komunikaty dziennika"
 ],
 "Login failed": [
  null,
  "Logowanie się nie powiodło"
 ],
 "Low profile desktop": [
  null,
  "Komputer stacjonarny o mniejszym rozmiarze"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (zalecane)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU musi być liczbą dodatnią"
 ],
 "Main server chassis": [
  null,
  "Główna obudowa serwera"
 ],
 "Manage storage": [
  null,
  "Zarządzanie urządzeniami do przechowywania danych"
 ],
 "Managed interfaces": [
  null,
  "Zarządzane interfejsy"
 ],
 "Manual": [
  null,
  "Ręczne"
 ],
 "Manually": [
  null,
  "Ręcznie"
 ],
 "Maximum message age $max_age": [
  null,
  "Maksymalny wiek komunikatu $max_age"
 ],
 "Message to logged in users": [
  null,
  "Wiadomość do zalogowanych użytkowników"
 ],
 "Metric": [
  null,
  "Statystyki"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Mode": [
  null,
  "Tryb"
 ],
 "Monitoring interval": [
  null,
  "Odstęp monitorowania"
 ],
 "Monitoring targets": [
  null,
  "Cele monitorowania"
 ],
 "Multi-system chassis": [
  null,
  "Obudowa dla wielu komputerów"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Można podać wiele adresów rozdzielonych przecinkami lub spacjami."
 ],
 "NSNA ping": [
  null,
  "Ping NSNA"
 ],
 "NTP server": [
  null,
  "Serwer NTP"
 ],
 "Name": [
  null,
  "Nazwa"
 ],
 "Need at least one NTP server": [
  null,
  "Wymagany jest co najmniej jeden serwer NTP"
 ],
 "Network bond": [
  null,
  "Wiązanie sieciowe"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Urządzenia i wykresy sieciowe wymagają usługi NetworkManager"
 ],
 "Network logs": [
  null,
  "Dzienniki sieci"
 ],
 "NetworkManager is not installed": [
  null,
  "Usługa NetworkManager nie jest zainstalowana"
 ],
 "NetworkManager is not running": [
  null,
  "Usługa NetworkManager nie jest uruchomiona"
 ],
 "Networking": [
  null,
  "Sieć"
 ],
 "New password was not accepted": [
  null,
  "Nie przyjęto nowego hasła"
 ],
 "No": [
  null,
  "Nie"
 ],
 "No carrier": [
  null,
  "Brak operatora"
 ],
 "No delay": [
  null,
  "Brak opóźnienia"
 ],
 "No description available": [
  null,
  "Brak dostępnego opisu"
 ],
 "No peers added.": [
  null,
  "Nie dodano żadnych partnerów."
 ],
 "No results found": [
  null,
  "Brak wyników"
 ],
 "No such file or directory": [
  null,
  "Nie ma takiego pliku lub katalogu"
 ],
 "No system modifications": [
  null,
  "Brak modyfikacji systemu"
 ],
 "None": [
  null,
  "Brak"
 ],
 "Not a valid private key": [
  null,
  "Nieprawidłowy klucz prywatny"
 ],
 "Not authorized to disable the firewall": [
  null,
  "Brak upoważnienia do wyłączenia zapory sieciowej"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Brak upoważnienia do włączenia zapory sieciowej"
 ],
 "Not available": [
  null,
  "Niedostępne"
 ],
 "Not permitted to perform this action.": [
  null,
  "Brak uprawnień do wykonania tego działania."
 ],
 "Not synchronized": [
  null,
  "Niesynchronizowane"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Occurrences": [
  null,
  "Wystąpienia"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "Nie przyjęto poprzedniego hasła"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Po zainstalowaniu programu Cockpit należy go włączyć za pomocą polecenia „systemctl enable --now cockpit.socket”."
 ],
 "Options": [
  null,
  "Opcje"
 ],
 "Other": [
  null,
  "Inne"
 ],
 "PackageKit crashed": [
  null,
  "Usługa PackageKit uległa awarii"
 ],
 "Parent": [
  null,
  "Nadrzędne"
 ],
 "Parent $parent": [
  null,
  "Nadrzędne $parent"
 ],
 "Part of $0": [
  null,
  "Część $0"
 ],
 "Passive": [
  null,
  "Pasywnie"
 ],
 "Password": [
  null,
  "Hasło"
 ],
 "Password is not acceptable": [
  null,
  "Hasło jest do przyjęcia"
 ],
 "Password is too weak": [
  null,
  "Hasło jest za słabe"
 ],
 "Password not accepted": [
  null,
  "Nie przyjęto hasła"
 ],
 "Paste": [
  null,
  "Wklej"
 ],
 "Paste error": [
  null,
  "Błąd wklejania"
 ],
 "Paste existing key": [
  null,
  "Wklej istniejący klucz"
 ],
 "Path cost": [
  null,
  "Koszt ścieżki"
 ],
 "Path cost $path_cost": [
  null,
  "Koszt ścieżki $path_cost"
 ],
 "Path to file": [
  null,
  "Ścieżka do pliku"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "$0. partner ma nieprawidłowy port punktu końcowego. Port musi być liczbą."
 ],
 "Peers": [
  null,
  "Partnerzy"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Partnerzy to inne komputery łączące się z tym. Klucze publiczne z innych komputerów będą udostępniane między nimi."
 ],
 "Peripheral chassis": [
  null,
  "Obudowa peryferyjna"
 ],
 "Permanent": [
  null,
  "Trwałe"
 ],
 "Pick date": [
  null,
  "Wybierz datę"
 ],
 "Ping interval": [
  null,
  "Odstęp między pingami"
 ],
 "Ping target": [
  null,
  "Cel pingu"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Please install the $0 package": [
  null,
  "Proszę zainstalować pakiet $0"
 ],
 "Portable": [
  null,
  "Przenośne"
 ],
 "Ports": [
  null,
  "Porty"
 ],
 "Prefix length": [
  null,
  "Długość przedrostka"
 ],
 "Prefix length or netmask": [
  null,
  "Długość przedrostka lub maska sieci"
 ],
 "Preparing": [
  null,
  "Przygotowywanie"
 ],
 "Present": [
  null,
  "Obecne"
 ],
 "Preserve": [
  null,
  "Zachowanie"
 ],
 "Primary": [
  null,
  "Główne"
 ],
 "Priority": [
  null,
  "Priorytet"
 ],
 "Priority $priority": [
  null,
  "Priorytet $priority"
 ],
 "Private key": [
  null,
  "Klucz prywatny"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Pytanie przez ssh-add przekroczyło czas oczekiwania"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Pytanie przez ssh-keygen przekroczyło czas oczekiwania"
 ],
 "Public key": [
  null,
  "Klucz publiczny"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Klucz publiczny zostanie utworzony po podaniu prawidłowego klucza prywatnego"
 ],
 "RAID chassis": [
  null,
  "Obudowa RAID"
 ],
 "Rack mount chassis": [
  null,
  "Obudowa do montowania w szafie"
 ],
 "Random": [
  null,
  "Losowo"
 ],
 "Range": [
  null,
  "Zakres"
 ],
 "Range must be strictly ordered": [
  null,
  "Zakres musi być w ścisłej kolejności"
 ],
 "Reboot": [
  null,
  "Uruchom ponownie"
 ],
 "Receiving": [
  null,
  "Odbieranie"
 ],
 "Regenerate": [
  null,
  "Utwórz ponownie"
 ],
 "Removals:": [
  null,
  "Usuwane:"
 ],
 "Remove $0": [
  null,
  "Usuń $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Usuń usługę $0 ze strefy $1"
 ],
 "Remove item": [
  null,
  "Usuń element"
 ],
 "Remove service $0": [
  null,
  "Usuń usługę $0"
 ],
 "Remove zone $0": [
  null,
  "Usuń strefę $0"
 ],
 "Removing $0": [
  null,
  "Usuwanie $0"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Usunięcie $0 zerwie połączenie z serwerem i uniemożliwi korzystanie z interfejsu administracji."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Usunięcie usługi Cockpit może spowodować niedostępność konsoli internetowej. Proszę się upewnić, że ta strefa nie ma zastosowania do obecnego połączenia konsoli internetowej."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Usunięcie strefy usunie wszystkie zawarte w niej usługi."
 ],
 "Restoring connection": [
  null,
  "Przywracanie połączenia"
 ],
 "Round robin": [
  null,
  "Round robin"
 ],
 "Routes": [
  null,
  "Trasy"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Należy wykonać to polecenie przez zaufaną sieć lub fizycznie na zdalnym komputerze:"
 ],
 "Runner": [
  null,
  "Uruchamianie"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Klucz SSH"
 ],
 "STP forward delay": [
  null,
  "Opóźnienie w przód STP"
 ],
 "STP hello time": [
  null,
  "Czas powitania STP"
 ],
 "STP maximum message age": [
  null,
  "Maksymalny wiek komunikatu STP"
 ],
 "STP priority": [
  null,
  "Priorytet STP"
 ],
 "Save": [
  null,
  "Zapisz"
 ],
 "Sealed-case PC": [
  null,
  "Sealed-case PC"
 ],
 "Search domain": [
  null,
  "Domena wyszukiwania"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Konfiguracja i rozwiązywanie błędów z SELinuksem"
 ],
 "Select method": [
  null,
  "Wybierz metodę"
 ],
 "Sending": [
  null,
  "Wysyłanie"
 ],
 "Server": [
  null,
  "Serwer"
 ],
 "Server has closed the connection.": [
  null,
  "Serwer zamknął połączenie."
 ],
 "Service": [
  null,
  "Usługa"
 ],
 "Services": [
  null,
  "Usługi"
 ],
 "Set time": [
  null,
  "Ustaw czas"
 ],
 "Set to": [
  null,
  "Ustaw na"
 ],
 "Shared": [
  null,
  "Współdzielone"
 ],
 "Shell script": [
  null,
  "Skrypt powłoki"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Shut down": [
  null,
  "Wyłącz"
 ],
 "Single rank": [
  null,
  "Pojedynczy stopień"
 ],
 "Sorted from least to most trusted": [
  null,
  "Uporządkowane od najmniej do najbardziej zaufanych"
 ],
 "Space-saving computer": [
  null,
  "Komputer oszczędzający miejsce"
 ],
 "Spanning tree protocol": [
  null,
  "Protokół STP"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Protokół STP"
 ],
 "Specific time": [
  null,
  "Podany czas"
 ],
 "Stable": [
  null,
  "Stabilna"
 ],
 "Start service": [
  null,
  "Uruchom usługę"
 ],
 "Status": [
  null,
  "Stan"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Sticky": [
  null,
  "Lepkie"
 ],
 "Storage": [
  null,
  "Przechowywanie danych"
 ],
 "Sub-Chassis": [
  null,
  "Obudowa podrzędna"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Switch off $0": [
  null,
  "Wyłącz $0"
 ],
 "Switch on $0": [
  null,
  "Włącz $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Wyłączenie $0 zerwie połączenie z serwerem i uniemożliwi korzystanie z interfejsu administracji."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Włączenie $0 zerwie połączenie z serwerem i uniemożliwi korzystanie z interfejsu administracji."
 ],
 "Synchronized": [
  null,
  "Synchronizowane"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizowane z $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizowanie"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Team": [
  null,
  "Zespół"
 ],
 "Team port": [
  null,
  "Port zespołu"
 ],
 "Team port settings": [
  null,
  "Ustawienia portu zespołu"
 ],
 "Testing connection": [
  null,
  "Testowanie połączenia"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Klucz SSH $0 użytkownika $1 na komputerze $2 zostanie dodany do pliku $3 użytkownika $4 na komputerze $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Klucz SSH $0 stanie się dostępny przez pozostały czas sesji i będzie dostępny do logowania także na innych komputerach."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Klucz SSH do logowania w $0 jest chroniony hasłem, ale komputer nie zezwala na logowanie za pomocą hasła. Proszę podać hasło klucza w $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Klucz SSH do logowania w $0 jest chroniony. Można zalogować się za pomocą hasła logowania lub podając hasło klucza w $1."
 ],
 "The cockpit service is automatically included": [
  null,
  "Usługa Cockpit jest automatycznie dołączana"
 ],
 "The fingerprint should match:": [
  null,
  "Odcisk powinien się zgadzać:"
 ],
 "The key password can not be empty": [
  null,
  "Hasło klucza nie może być puste"
 ],
 "The key passwords do not match": [
  null,
  "Hasła klucza się nie zgadzają"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Zalogowany użytkownik nie ma zezwolenia na wyświetlanie modyfikacji systemu"
 ],
 "The password can not be empty": [
  null,
  "Hasło nie może być puste"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Powstały odcisk można udostępniać publicznie, na przykład przez e-mail."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Powstały odcisk można udostępniać publicznie, na przykład przez e-mail. Jeśli weryfikacja jest wykonywana za użytkownika przez kogoś innego, to ta osoba może wysłać wyniki na dowolny sposób."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Serwer odmówił uwierzytelnienia za pomocą wszystkich obsługiwanych metod."
 ],
 "There are no active services in this zone": [
  null,
  "Brak aktywnych usług w tej strefie"
 ],
 "This device cannot be managed here.": [
  null,
  "Tutaj nie można zarządzać tym urządzeniem."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "To narzędzie konfiguruje zasady SELinuksa i może pomóc w zrozumieniu i rozwiązywaniu naruszeń zasad."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "To narzędzie tworzy archiwum konfiguracji i informacji diagnostycznych z działającego komputera. Archiwum może być przechowywane lokalnie lub centralnie do celów nagrywania i śledzenia, albo może być wysyłane do przedstawicieli pomocy technicznej, programistów lub administratorów komputera w celu wspomagania znajdowania źródła problemu i debugowania."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "To narzędzie zarządza lokalnymi urządzeniami do przechowywania danych, takimi jak systemy plików, grupy woluminów LVM2 czy punkty montowania NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "To narzędzie zarządza sieciami, takimi jak wiązania, mostki, zespoły, VLAN i zapory sieciowe za pomocą usług NetworkManager i firewalld. Usługa NetworkManager jest niezgodna z domyślnymi skryptami systemd-networkd systemu Ubuntu i ifupdown systemu Debian."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Ta strefa zawiera usługę Cockpit. Proszę się upewnić, że ta strefa nie ma zastosowania do obecnego połączenia konsoli internetowej."
 ],
 "Time zone": [
  null,
  "Strefa czasowa"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Aby upewnić się, że połączenie nie jest przechwytywane przez szkodliwą stronę trzecią, proszę zweryfikować odcisk klucza komputera:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Aby zweryfikować odcisk klucza, należy wykonać poniższe polecenie na $0 fizycznie siedząc przy komputerze lub przez zaufaną sieć:"
 ],
 "Toggle date picker": [
  null,
  "Przełącz wybór daty"
 ],
 "Too much data": [
  null,
  "Za dużo danych"
 ],
 "Total size: $0": [
  null,
  "Całkowity rozmiar: $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Transmitting": [
  null,
  "Przesyłanie"
 ],
 "Troubleshoot…": [
  null,
  "Rozwiąż problem…"
 ],
 "Trust and add host": [
  null,
  "Zaufaj i dodaj komputer"
 ],
 "Trust level": [
  null,
  "Poziom zaufania"
 ],
 "Trying to synchronize with $0": [
  null,
  "Próbowanie synchronizacji z $0"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nie można zalogować się w $0. Komputer nie przyjmuje logowania hasłem ani żadnego z kluczy SSH użytkownika."
 ],
 "Unexpected error": [
  null,
  "Nieoczekiwany błąd"
 ],
 "Unknown": [
  null,
  "Nieznane"
 ],
 "Unknown \"$0\"": [
  null,
  "Nieznane „$0”"
 ],
 "Unknown configuration": [
  null,
  "Nieznana konfiguracja"
 ],
 "Unknown service name": [
  null,
  "Nieznana nazwa usługi"
 ],
 "Unmanaged interfaces": [
  null,
  "Niezarządzane interfejsy"
 ],
 "Untrusted host": [
  null,
  "Niezaufany komputer"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "Identyfikator VLAN"
 ],
 "Verify fingerprint": [
  null,
  "Zweryfikuj odcisk"
 ],
 "View all logs": [
  null,
  "Wszystkie dzienniki"
 ],
 "View automation script": [
  null,
  "Wyświetl skrypt automatyzacji"
 ],
 "Visit firewall": [
  null,
  "Otwórz zaporę sieciową"
 ],
 "Waiting": [
  null,
  "Oczekiwanie"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Oczekiwanie na ukończenie pozostałych działań zarządzania oprogramowaniem"
 ],
 "Web Console for Linux servers": [
  null,
  "Konsola internetowa dla serwerów systemu Linux"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Zostanie ustawione na „Automatyczne”"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "Tak"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Łączenie z $0 po raz pierwszy."
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Brak upoważnienia do modyfikacji zapory sieciowej."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Używana przeglądarka nie zezwala na wklejanie z menu kontekstowego. Można użyć klawiszy Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Sesja została zakończona."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sesja wygasła. Proszę zalogować się ponownie."
 ],
 "Zone": [
  null,
  "Strefa"
 ],
 "[binary data]": [
  null,
  "[dane binarne]"
 ],
 "[no data]": [
  null,
  "[brak danych]"
 ],
 "edit": [
  null,
  "modyfikuj"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "jakość hasła"
 ],
 "show less": [
  null,
  "wyświetl mniej"
 ],
 "show more": [
  null,
  "wyświetl więcej"
 ],
 "wireguard-tools package is not installed": [
  null,
  "Pakiet wireguard-tools nie jest zainstalowany"
 ]
});
