cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ko",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "진단 보고서"
 ],
 "Kernel dump": [
  null,
  "커널 덤프"
 ],
 "Managing VLANs": [
  null,
  "VLAN 관리"
 ],
 "Managing firewall": [
  null,
  "방화벽 관리"
 ],
 "Managing networking bonds": [
  null,
  "네트워킹 본드 관리"
 ],
 "Managing networking bridges": [
  null,
  "네트워킹 브릿지 관리"
 ],
 "Managing networking teams": [
  null,
  "네트워킹 팀 관리"
 ],
 "Networking": [
  null,
  "네트워킹"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "서비스"
 ],
 "Storage": [
  null,
  "저장소"
 ],
 "bond": [
  null,
  "본드"
 ],
 "bridge": [
  null,
  "브릿지"
 ],
 "firewall": [
  null,
  "방화벽"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "연결장치"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "네트워크"
 ],
 "port": [
  null,
  "포트"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "팀"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "영역"
 ]
});
