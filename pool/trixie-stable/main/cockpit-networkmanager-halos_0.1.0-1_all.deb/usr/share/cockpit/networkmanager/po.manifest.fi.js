cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Managing VLANs": [
  null,
  "VLANien hallinta"
 ],
 "Managing firewall": [
  null,
  "Palomuurin hallinta"
 ],
 "Managing networking bonds": [
  null,
  "Verkkosidosten hallinta"
 ],
 "Managing networking bridges": [
  null,
  "Verkkosiltojen hallinta"
 ],
 "Managing networking teams": [
  null,
  "Verkkojoukkojen hallinta"
 ],
 "Networking": [
  null,
  "Verkko"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Palvelut"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "bond": [
  null,
  "sidos"
 ],
 "bridge": [
  null,
  "silta"
 ],
 "firewall": [
  null,
  "palomuuri"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "liitäntä"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "verkko"
 ],
 "port": [
  null,
  "portti"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "joukkue"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "vyöhyke"
 ]
});
