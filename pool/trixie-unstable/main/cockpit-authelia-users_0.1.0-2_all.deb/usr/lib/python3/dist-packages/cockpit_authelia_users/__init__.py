"""Cockpit Authelia Users - Backend for Authelia user management."""

__version__ = "0.1.0"
