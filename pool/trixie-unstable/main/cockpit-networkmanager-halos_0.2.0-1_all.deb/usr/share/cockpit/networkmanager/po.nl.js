cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nl",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 active zone": [
  null,
  "$0 actieve zone",
  "$0 actieve zones"
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dagen"
 ],
 "$0 exited with code $1": [
  null,
  "$0 verlaten met code $1"
 ],
 "$0 failed": [
  null,
  "$0 mislukte"
 ],
 "$0 hour": [
  null,
  "$0 uur",
  "$0 uren"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 is van geen enkele repository beschikbaar."
 ],
 "$0 key changed": [
  null,
  "$0 sleutel gewijzigd"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 is afgeschoten met signaal $1"
 ],
 "$0 minute": [
  null,
  "$0 minuut",
  "$0 minuten"
 ],
 "$0 month": [
  null,
  "$0 maand",
  "$0 maanden"
 ],
 "$0 week": [
  null,
  "$0 week",
  "$0 weken"
 ],
 "$0 will be installed.": [
  null,
  "$0 zal geïnstalleerd worden."
 ],
 "$0 year": [
  null,
  "$0 jaar",
  "$0 jaren"
 ],
 "$0 zone": [
  null,
  "$0 zone"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 hour": [
  null,
  "1 uur"
 ],
 "1 minute": [
  null,
  "1 minuut"
 ],
 "1 week": [
  null,
  "1 week"
 ],
 "20 minutes": [
  null,
  "20 minuten"
 ],
 "40 minutes": [
  null,
  "40 minuten"
 ],
 "5 minutes": [
  null,
  "5 minuten"
 ],
 "6 hours": [
  null,
  "6 uren"
 ],
 "60 minutes": [
  null,
  "60 minuten"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Er is geen compatibele versie van Cockpit geïnstalleerd op $0."
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Een netwerkverbinding combineert meerdere netwerkinterfaces tot één logische interface met een hogere doorvoer of redundantie."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Een nieuwe SSH-sleutel op $0 wordt gemaakt voor $1 op $2 en deze wordt toegevoegd aan het $3-bestand van $4 op $5."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "ARP-bewaking"
 ],
 "ARP ping": [
  null,
  "ARP-ping"
 ],
 "Absent": [
  null,
  "Afwezig"
 ],
 "Acceptable password": [
  null,
  "Acceptabel wachtwoord"
 ],
 "Actions": [
  null,
  "Acties"
 ],
 "Active": [
  null,
  "Actief"
 ],
 "Active backup": [
  null,
  "Actieve back-up"
 ],
 "Adaptive load balancing": [
  null,
  "Adaptieve taakverdeling"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Adaptieve overdrachtstaakverdeling"
 ],
 "Add": [
  null,
  "Toevoegen"
 ],
 "Add $0": [
  null,
  "Toevoegen $0"
 ],
 "Add DNS server": [
  null,
  "Voeg DNS-server toe"
 ],
 "Add VLAN": [
  null,
  "VLAN toevoegen"
 ],
 "Add VPN": [
  null,
  "VPN toevoegen"
 ],
 "Add WireGuard VPN": [
  null,
  "WireGuard VPN toevoegen"
 ],
 "Add a new zone": [
  null,
  "Een nieuwe zone toevoegen"
 ],
 "Add address": [
  null,
  "Voeg adres toe"
 ],
 "Add bond": [
  null,
  "Binding toevoegen"
 ],
 "Add bridge": [
  null,
  "Brug toevoegen"
 ],
 "Add member": [
  null,
  "Voeg lid toe"
 ],
 "Add new zone": [
  null,
  "Nieuwe zone toevoegen"
 ],
 "Add peer": [
  null,
  "Voeg gelijke toe"
 ],
 "Add ports": [
  null,
  "Poorten toevoegen"
 ],
 "Add ports to $0 zone": [
  null,
  "Poorten toevoegen aan $0 zone"
 ],
 "Add route": [
  null,
  "Voeg route toe"
 ],
 "Add search domain": [
  null,
  "Voeg zoekdomein toe"
 ],
 "Add services": [
  null,
  "Services toevoegen"
 ],
 "Add services to $0 zone": [
  null,
  "Services toevoegen aan $0 zone"
 ],
 "Add services to zone $0": [
  null,
  "Services toevoegen aan zone $0"
 ],
 "Add team": [
  null,
  "Team toevoegen"
 ],
 "Add zone": [
  null,
  "Zone toevoegen"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Toevoegen van $0 verbreekt de verbinding met de server en maakt de beheerdersinterface onbereikbaar."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Door aangepaste poorten toe te voegen, wordt 'firewalld' opnieuw geladen. Herladen zal leiden tot het verlies van elke runtime-only-configuratie!"
 ],
 "Additional DNS $val": [
  null,
  "Extra DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Extra DNS-zoekdomeinen $val"
 ],
 "Additional address $val": [
  null,
  "Extra adres $val"
 ],
 "Additional packages:": [
  null,
  "Extra pakketten:"
 ],
 "Additional ports": [
  null,
  "Extra poorten"
 ],
 "Address": [
  null,
  "Adres"
 ],
 "Address $val": [
  null,
  "Adres $val"
 ],
 "Addresses": [
  null,
  "Adressen"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Adressen zijn niet correct geformatteerd"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Beheer met Cockpit Web Console"
 ],
 "Advanced TCA": [
  null,
  "Geavanceerde TCA"
 ],
 "All-in-one": [
  null,
  "Alles in een"
 ],
 "Allowed IPs": [
  null,
  "Toegestane IP's"
 ],
 "Allowed addresses": [
  null,
  "Toegestane adressen"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible rollen documentatie"
 ],
 "Authenticating": [
  null,
  "Authenticatie uitvoeren"
 ],
 "Authentication": [
  null,
  "Authenticatie"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Authenticatie is vereist voor het uitvoeren van bevoorrechte taken met de Cockpit Web Console"
 ],
 "Authorize SSH key": [
  null,
  "Autoriseer SSH-sleutel"
 ],
 "Automatic": [
  null,
  "Automatisch"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automatisch (alleen DHCP)"
 ],
 "Automatically using NTP": [
  null,
  "Automatisch gebruik van NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatisch gebruik van extra NTP servers"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisch gebruik van specifieke NTP servers"
 ],
 "Automation script": [
  null,
  "Automatiserings-script"
 ],
 "Balancer": [
  null,
  "Balancer"
 ],
 "Blade": [
  null,
  "Antenne"
 ],
 "Blade enclosure": [
  null,
  "Antennebehuizing"
 ],
 "Bond": [
  null,
  "Binding"
 ],
 "Bridge": [
  null,
  "Brug"
 ],
 "Bridge port": [
  null,
  "Brugpoort"
 ],
 "Bridge port settings": [
  null,
  "Brugpoort instellingen"
 ],
 "Broadcast": [
  null,
  "Uitzending"
 ],
 "Broken configuration": [
  null,
  "Defecte configuratie"
 ],
 "Bus expansion chassis": [
  null,
  "Busuitbreidingschassis"
 ],
 "Cancel": [
  null,
  "Annuleren"
 ],
 "Cannot forward login credentials": [
  null,
  "Kan inloggegevens niet doorsturen"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan evenement niet in het verleden plannen"
 ],
 "Carrier": [
  null,
  "Carrier"
 ],
 "Change": [
  null,
  "Verandering"
 ],
 "Change system time": [
  null,
  "Verander systeemtijd"
 ],
 "Change the settings": [
  null,
  "Verander de instellingen"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Gewijzigde sleutels zijn vaak het resultaat van een herinstallatie van het besturingssysteem. Een onverwachte wijziging kan echter wijzen op een poging van derden om je verbinding te onderscheppen."
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Als je de instellingen wijzigt, wordt de verbinding met de server verbroken en is de beheerdersinterface niet beschikbaar."
 ],
 "Checking IP": [
  null,
  "Controleren van IP"
 ],
 "Checking installed software": [
  null,
  "Controleren op geïnstalleerde software"
 ],
 "Clear input value": [
  null,
  "Invoerwaarde wissen"
 ],
 "Close": [
  null,
  "Sluiten"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit configuratie van NetworkManager en Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit kon geen contact maken met de opgegeven host."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit is een serverbeheerder waarmee je Linux-servers eenvoudig kunt beheren via een webbrowser. Omschakelen tussen de terminal en het webgereedschap is geen probleem. Een service gestart via Cockpit kan via de terminal worden gestopt. Evenzo, als er een fout optreedt in de terminal, kan deze worden gezien in de Cockpit-logboekinterface."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit is niet compatibel met de software op het systeem."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit is niet geïnstalleerd"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit is niet op het systeem geïnstalleerd."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit is perfect voor nieuwe systeembeheerders, waardoor ze eenvoudig eenvoudige taken kunnen uitvoeren, zoals opslagbeheer, het inspecteren van logboeken en het starten en stoppen van services. Je kunt meerdere servers tegelijkertijd bewaken en beheren. Voeg ze gewoon toe met een enkele klik en je machines zullen voor zijn maatjes zorgen."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Verzamel en verpak diagnostische en ondersteuningsdata"
 ],
 "Collect kernel crash dumps": [
  null,
  "Verzamel kernelcrashdumps"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Door komma's gescheiden poorten, bereiken en services worden geaccepteerd"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Configuring": [
  null,
  "Configureren"
 ],
 "Configuring IP": [
  null,
  "Configureren van IP"
 ],
 "Confirm key password": [
  null,
  "Bevestig sleutelwachtwoord"
 ],
 "Confirm removal of $0": [
  null,
  "Bevestig het verwijderen van $0"
 ],
 "Connect automatically": [
  null,
  "Verbind automatisch"
 ],
 "Connection has timed out.": [
  null,
  "Er is een time-out opgetreden voor de verbinding."
 ],
 "Connection will be lost": [
  null,
  "Verbinding wordt verbroken"
 ],
 "Convertible": [
  null,
  "Converteerbaar"
 ],
 "Copied": [
  null,
  "Gekopieerd"
 ],
 "Copy": [
  null,
  "Kopiëren"
 ],
 "Copy to clipboard": [
  null,
  "Kopiëren naar clipboard"
 ],
 "Create $0": [
  null,
  "Maak $0 aan"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Maak een nieuwe SSH-sleutel en autoriseer deze"
 ],
 "Create it": [
  null,
  "Maak het aan"
 ],
 "Create new task file with this content.": [
  null,
  "Maak nieuw taakbestand aan met deze inhoud."
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Het aanmaken van deze $0 zal de verbinding met de server verbreken waardoor deze beheerdersinterface niet meer beschikbaar zal zijn."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Custom ports": [
  null,
  "Aangepaste poorten"
 ],
 "Custom zones": [
  null,
  "Aangepaste zones"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "DNS zoekdomeinen"
 ],
 "DNS search domains $val": [
  null,
  "DNS zoekdomeinen $val"
 ],
 "Deactivating": [
  null,
  "Wordt gedeactiveerd"
 ],
 "Delay": [
  null,
  "Vertraging"
 ],
 "Delete": [
  null,
  "Verwijderen"
 ],
 "Delete $0": [
  null,
  "Verwijder $0"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Verwijderen van $0 verbreekt de verbinding met de server waardoor de beheerdersinterface niet meer beschikbaar zal zijn."
 ],
 "Description": [
  null,
  "Beschrijving"
 ],
 "Desktop": [
  null,
  "Bureaublad"
 ],
 "Detachable": [
  null,
  "Demonteerbaar"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostische rapporten"
 ],
 "Disable the firewall": [
  null,
  "Schakel de firewall uit"
 ],
 "Disabled": [
  null,
  "Uitgeschakeld"
 ],
 "Docking station": [
  null,
  "Docking station"
 ],
 "Downloading $0": [
  null,
  "$0 downloaden"
 ],
 "Dual rank": [
  null,
  "Dubbele rangorde"
 ],
 "Edit": [
  null,
  "Bewerken"
 ],
 "Edit VLAN settings": [
  null,
  "Bewerk VLAN-instellingen"
 ],
 "Edit WireGuard VPN": [
  null,
  "Bewerk WireGuard VPN"
 ],
 "Edit bond settings": [
  null,
  "Bewerk bindingsinstellingen"
 ],
 "Edit bridge settings": [
  null,
  "Bewerk bruginstellingen"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Bewerk aangepaste service in $0 zone"
 ],
 "Edit rules and zones": [
  null,
  "Bewerk regels en zones"
 ],
 "Edit service": [
  null,
  "Bewerk service"
 ],
 "Edit service $0": [
  null,
  "Bewerk service $0"
 ],
 "Edit team settings": [
  null,
  "Bewerk teaminstellingen"
 ],
 "Embedded PC": [
  null,
  "Ingebouwde pc"
 ],
 "Enable or disable the device": [
  null,
  "Schakel het apparaat in of uit"
 ],
 "Enable service": [
  null,
  "Service inschakelen"
 ],
 "Enable the firewall": [
  null,
  "Schakel de firewall in"
 ],
 "Enabled": [
  null,
  "Ingeschakeld"
 ],
 "Endpoint": [
  null,
  "Eindpunt"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "Het eindpunt dat als \"server\" fungeert, moet worden opgegeven als host:poort, anders kan het leeg worden gelaten."
 ],
 "Enter a valid MAC address": [
  null,
  "Voer een geldig MAC-adres in"
 ],
 "Entire subnet": [
  null,
  "Volledig subnet"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet MTU"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Voorbeeld: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Voorbeeld: 88,2019,nfs,rsync"
 ],
 "Excellent password": [
  null,
  "Uitstekend wachtwoord"
 ],
 "Expansion chassis": [
  null,
  "Uitbreidingschassis"
 ],
 "Failed": [
  null,
  "Mislukt"
 ],
 "Failed to add port": [
  null,
  "Kan poort niet toevoegen"
 ],
 "Failed to add service": [
  null,
  "Kan service niet toevoegen"
 ],
 "Failed to add zone": [
  null,
  "Kan zone niet toevoegen"
 ],
 "Failed to change password": [
  null,
  "Kan wachtwoord niet veranderen"
 ],
 "Failed to edit service": [
  null,
  "Service bewerken mislukte"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Kan $0 niet inschakelen in firewalld"
 ],
 "Failed to save settings": [
  null,
  "Kan instellingen niet opslaan"
 ],
 "Filter services": [
  null,
  "Filter services"
 ],
 "Firewall": [
  null,
  "Firewall"
 ],
 "Firewall is not available": [
  null,
  "Firewall is niet beschikbaar"
 ],
 "Forward delay $forward_delay": [
  null,
  "Voorwaartse vertraging $forward_delay"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "Gateway $gateway": [
  null,
  "Gateway $gateway"
 ],
 "General": [
  null,
  "Algemeen"
 ],
 "Generated": [
  null,
  "Gegenereerd"
 ],
 "Go to now": [
  null,
  "Ga nu naar"
 ],
 "Group": [
  null,
  "Groep"
 ],
 "Hair pin mode": [
  null,
  "Haarspeld modus"
 ],
 "Hairpin mode": [
  null,
  "Haarspeld modus"
 ],
 "Handheld": [
  null,
  "Handheld"
 ],
 "Hello time $hello_time": [
  null,
  "Hallo tijd $hello_time"
 ],
 "Hide confirmation password": [
  null,
  "Bevestigingswachtwoord verbergen"
 ],
 "Hide password": [
  null,
  "Wachtwoord verbergen"
 ],
 "Host key is incorrect": [
  null,
  "Hostsleutel is onjuist"
 ],
 "ID": [
  null,
  "ID"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "IP address": [
  null,
  "IP-adres"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP-adres met routeprefix. Scheid meerdere waarden met een komma. Voorbeeld: 192.0.2.0/24, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 settings": [
  null,
  "IPv4-instellingen"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "IPv6-instellingen"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Indien leeg gelaten, wordt ID gegenereerd op basis van bijbehorende poortservices en poortnummers"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Als de vingerafdruk overeenkomt, klik dan op 'Vertrouw en host toevoegen'. Verbind anders niet en neem contact op met je beheerder."
 ],
 "Ignore": [
  null,
  "Negeren"
 ],
 "Inactive": [
  null,
  "Inactief"
 ],
 "Included services": [
  null,
  "Inbegrepen services"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Inkomende verzoeken worden standaard geblokkeerd. Uitgaande verzoeken worden niet geblokkeerd."
 ],
 "Install": [
  null,
  "Installeren"
 ],
 "Install software": [
  null,
  "Installeer software"
 ],
 "Installing $0": [
  null,
  "$0 installeren"
 ],
 "Interface": [
  null,
  "Interface",
  "Interfaces"
 ],
 "Interface members": [
  null,
  "Interface leden"
 ],
 "Interfaces": [
  null,
  "Interfaces"
 ],
 "Internal error": [
  null,
  "Interne fout"
 ],
 "Invalid address $0": [
  null,
  "Ongeldig adres $0"
 ],
 "Invalid date format": [
  null,
  "Ongeldige datum"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ongeldige datumnotatie en ongeldige tijdnotatie"
 ],
 "Invalid file permissions": [
  null,
  "Ongeldige bestandsrechten"
 ],
 "Invalid metric $0": [
  null,
  "Ongeldige metriek $0"
 ],
 "Invalid port number": [
  null,
  "Ongeldig poortnummer"
 ],
 "Invalid prefix $0": [
  null,
  "Ongeldig voorvoegsel $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Ongeldig voorvoegsel of netmasker $0"
 ],
 "Invalid range": [
  null,
  "Ongeldig bereik"
 ],
 "Invalid time format": [
  null,
  "Ongeldige tijdnotatie"
 ],
 "Invalid timezone": [
  null,
  "Ongeldige tijdzone"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Keep connection": [
  null,
  "Houd verbinding"
 ],
 "Kernel dump": [
  null,
  "Kerneldump"
 ],
 "Key password": [
  null,
  "Sleutelwachtwoord"
 ],
 "LACP key": [
  null,
  "LACP-sleutel"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Learn more": [
  null,
  "Kom meer te weten"
 ],
 "Link down delay": [
  null,
  "Link down vertraging"
 ],
 "Link local": [
  null,
  "Link lokaal"
 ],
 "Link monitoring": [
  null,
  "Link monitoring"
 ],
 "Link up delay": [
  null,
  "Link up vertraging"
 ],
 "Link watch": [
  null,
  "Link toezicht"
 ],
 "Listen port": [
  null,
  "Luisterpoort"
 ],
 "Listen port must be a number": [
  null,
  "Luisterpoort moet een getal zijn"
 ],
 "Load balancing": [
  null,
  "Taakverdeling"
 ],
 "Loading system modifications...": [
  null,
  "Systeemwijzigingen laden..."
 ],
 "Log in": [
  null,
  "Inloggen"
 ],
 "Log in to $0": [
  null,
  "Log in op $0"
 ],
 "Log messages": [
  null,
  "Log berichten"
 ],
 "Login failed": [
  null,
  "Inloggen mislukte"
 ],
 "Low profile desktop": [
  null,
  "Laag profiel bureaublad"
 ],
 "Lunch box": [
  null,
  "Lunchbox"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (Aanbevolen)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU moet een positief getal zijn"
 ],
 "Main server chassis": [
  null,
  "Hoofdserverchassis"
 ],
 "Manage storage": [
  null,
  "Beheerde opslag"
 ],
 "Managed interfaces": [
  null,
  "Beheerde interfaces"
 ],
 "Manual": [
  null,
  "Handmatig"
 ],
 "Manually": [
  null,
  "Handmatig"
 ],
 "Maximum message age $max_age": [
  null,
  "Maximale berichtleeftijd $max_age"
 ],
 "Message to logged in users": [
  null,
  "Bericht aan ingelogde gebruikers"
 ],
 "Metric": [
  null,
  "Metriek"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Mode": [
  null,
  "Modus"
 ],
 "Monitoring interval": [
  null,
  "Bewakingsinterval"
 ],
 "Monitoring targets": [
  null,
  "Doelen controleren"
 ],
 "Multi-system chassis": [
  null,
  "Chassis met meerdere systemen"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Er kunnen meerdere adressen worden opgegeven met komma's of spaties als scheidingstekens."
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "NTP server": [
  null,
  "NTP-server"
 ],
 "Name": [
  null,
  "Naam"
 ],
 "Need at least one NTP server": [
  null,
  "Minimaal één NTP-server nodig"
 ],
 "Network bond": [
  null,
  "Netwerkbinding"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Netwerkapparaten en grafieken vereisen NetworkManager"
 ],
 "Network logs": [
  null,
  "Netwerklogboeken"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager is niet geïnstalleerd"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager is niet actief"
 ],
 "Networking": [
  null,
  "Netwerken"
 ],
 "New password was not accepted": [
  null,
  "Nieuw wachtwoord is niet geaccepteerd"
 ],
 "No": [
  null,
  "Nee"
 ],
 "No carrier": [
  null,
  "Geen signaal"
 ],
 "No delay": [
  null,
  "Geen vertraging"
 ],
 "No description available": [
  null,
  "Geen beschrijving beschikbaar"
 ],
 "No peers added.": [
  null,
  "Geen gelijken toegevoegd."
 ],
 "No results found": [
  null,
  "Geen resultaten gevonden"
 ],
 "No such file or directory": [
  null,
  "Bestand of map bestaat niet"
 ],
 "No system modifications": [
  null,
  "Geen systeemwijzigingen"
 ],
 "None": [
  null,
  "Geen"
 ],
 "Not a valid private key": [
  null,
  "Geen geldige privésleutel"
 ],
 "Not authorized to disable the firewall": [
  null,
  "Niet gemachtigd om de firewall uit te schakelen"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Niet gemachtigd om de firewall in te schakelen"
 ],
 "Not available": [
  null,
  "Niet beschikbaar"
 ],
 "Not permitted to perform this action.": [
  null,
  "Niet toegestaan om deze actie uit te voeren."
 ],
 "Not synchronized": [
  null,
  "Niet gesynchroniseerd"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Occurrences": [
  null,
  "Voorvallen"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "Oude wachtwoord niet geaccepteerd"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Nadat Cockpit geïnstalleerd is, schakel je het in met \"systemctl enable --now cockpit.socket\"."
 ],
 "Options": [
  null,
  "Opties"
 ],
 "Other": [
  null,
  "Andere"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit is gecrasht"
 ],
 "Parent": [
  null,
  "Ouder"
 ],
 "Parent $parent": [
  null,
  "Ouder $parent"
 ],
 "Part of $0": [
  null,
  "Onderdeel van $0"
 ],
 "Passive": [
  null,
  "Passief"
 ],
 "Password": [
  null,
  "Wachtwoord"
 ],
 "Password is not acceptable": [
  null,
  "Wachtwoord is niet acceptabel"
 ],
 "Password is too weak": [
  null,
  "Wachtwoord is te zwak"
 ],
 "Password not accepted": [
  null,
  "Wachtwoord wordt niet geaccepteerd"
 ],
 "Paste": [
  null,
  "Plakken"
 ],
 "Paste error": [
  null,
  "Plakfout"
 ],
 "Paste existing key": [
  null,
  "Plak een bestaande sleutel"
 ],
 "Path cost": [
  null,
  "Padkosten"
 ],
 "Path cost $path_cost": [
  null,
  "Pad kost $path_cost"
 ],
 "Path to file": [
  null,
  "Pad naar bestand"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "Peer #$0 heeft een ongeldige eindpuntpoort. Poort moet een getal zijn."
 ],
 "Peers": [
  null,
  "Peers"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Peers zijn andere machines die verbinding maken met deze. Openbare sleutels van andere machines worden met elkaar gedeeld."
 ],
 "Peripheral chassis": [
  null,
  "Randchassis"
 ],
 "Permanent": [
  null,
  "Blijvend"
 ],
 "Pick date": [
  null,
  "Kies datum"
 ],
 "Ping interval": [
  null,
  "Ping interval"
 ],
 "Ping target": [
  null,
  "Ping doel"
 ],
 "Pizza box": [
  null,
  "Pizzadoos"
 ],
 "Please install the $0 package": [
  null,
  "Installeer het $0 pakket"
 ],
 "Portable": [
  null,
  "Draagbaar"
 ],
 "Ports": [
  null,
  "Poorten"
 ],
 "Prefix length": [
  null,
  "Voorvoegsel-lengte"
 ],
 "Prefix length or netmask": [
  null,
  "Voorvoegsel-lengte of netmasker"
 ],
 "Preparing": [
  null,
  "Voorbereiden"
 ],
 "Present": [
  null,
  "Aanwezig"
 ],
 "Preserve": [
  null,
  "Behouden"
 ],
 "Primary": [
  null,
  "Primair"
 ],
 "Priority": [
  null,
  "Prioriteit"
 ],
 "Priority $priority": [
  null,
  "Prioriteit $priority"
 ],
 "Private key": [
  null,
  "Privé sleutel"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Vragen via ssh-add is verlopen"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Vragen ssh-keygen is verlopen"
 ],
 "Public key": [
  null,
  "Publieke sleutel"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Er wordt een publieke sleutel gegenereerd wanneer een geldige privésleutel wordt ingevoerd"
 ],
 "RAID chassis": [
  null,
  "RAID-chassis"
 ],
 "Rack mount chassis": [
  null,
  "Rackmontagechassis"
 ],
 "Random": [
  null,
  "Willekeurig"
 ],
 "Range": [
  null,
  "Reeks"
 ],
 "Range must be strictly ordered": [
  null,
  "Bereik moet strikt geordend zijn"
 ],
 "Reboot": [
  null,
  "Opnieuw opstarten"
 ],
 "Receiving": [
  null,
  "Ontvangen"
 ],
 "Regenerate": [
  null,
  "Regenereer"
 ],
 "Removals:": [
  null,
  "Verwijderingen:"
 ],
 "Remove $0": [
  null,
  "Verwijder $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Verwijder $0 service uit $1 zone"
 ],
 "Remove item": [
  null,
  "Verwijder item"
 ],
 "Remove service $0": [
  null,
  "Verwijder service $0"
 ],
 "Remove zone $0": [
  null,
  "Verwijder zone $0"
 ],
 "Removing $0": [
  null,
  "$0 verwijderen"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Als je $0 verwijdert, wordt de verbinding met de server verbroken en wordt de beheerdersinterface onbereikbaar."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Als je de cockpit-service verwijdert, kan de webconsole onbereikbaar worden. Zorg ervoor dat deze zone niet van toepassing is op je huidige webconsoleverbinding."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Als je de zone verwijdert, worden alle services erin verwijderd."
 ],
 "Restoring connection": [
  null,
  "Verbinding herstellen"
 ],
 "Round robin": [
  null,
  "Round-robin"
 ],
 "Routes": [
  null,
  "Routes"
 ],
 "Row select": [
  null,
  "Selecteer rij"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Voer deze opdracht uit via een vertrouwd netwerk of fysiek op de externe machine:"
 ],
 "Runner": [
  null,
  "Uitvoerder"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-sleutel"
 ],
 "STP forward delay": [
  null,
  "STP voorwaartse vertraging"
 ],
 "STP hello time": [
  null,
  "STP hallo tijd"
 ],
 "STP maximum message age": [
  null,
  "STP maximale berichtleeftijd"
 ],
 "STP priority": [
  null,
  "STP prioriteit"
 ],
 "Save": [
  null,
  "Opslaan"
 ],
 "Sealed-case PC": [
  null,
  "Gesloten PC"
 ],
 "Search domain": [
  null,
  "Zoek domein"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux configuratie en probleemoplossing"
 ],
 "Select method": [
  null,
  "Selecteer methode"
 ],
 "Sending": [
  null,
  "Verzenden"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server has closed the connection.": [
  null,
  "Server heeft de verbinding verbroken."
 ],
 "Service": [
  null,
  "Service"
 ],
 "Services": [
  null,
  "Services"
 ],
 "Set time": [
  null,
  "Stel tijd in"
 ],
 "Set to": [
  null,
  "Stel in op"
 ],
 "Shared": [
  null,
  "Gedeeld"
 ],
 "Shell script": [
  null,
  "Shell-script"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Bevestigingswachtwoord tonen"
 ],
 "Show password": [
  null,
  "Wachtwoord tonen"
 ],
 "Shut down": [
  null,
  "Afsluiten"
 ],
 "Single rank": [
  null,
  "Enkele rang"
 ],
 "Sorted from least to most trusted": [
  null,
  "Gesorteerd van minst tot meest vertrouwd"
 ],
 "Space-saving computer": [
  null,
  "Ruimtebesparende computer"
 ],
 "Spanning tree protocol": [
  null,
  "Spanning tree protocol"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Spanning tree protocol (STP)"
 ],
 "Specific time": [
  null,
  "Specifieke tijd"
 ],
 "Stable": [
  null,
  "Stabiel"
 ],
 "Start service": [
  null,
  "Start service"
 ],
 "Status": [
  null,
  "Toestand"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Sticky": [
  null,
  "Kleverig"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "Strong password": [
  null,
  "Sterk wachtwoord"
 ],
 "Sub-Chassis": [
  null,
  "Sub-chassis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-notebook"
 ],
 "Switch off $0": [
  null,
  "Schakel $0 uit"
 ],
 "Switch on $0": [
  null,
  "Schakel $0 in"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Als je $0 uitschakelt, wordt de verbinding met de server verbroken en is de beheerdersinterface niet beschikbaar."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Als je $0 inschakelt, wordt de verbinding met de server verbroken en is de beheerdersinterface niet beschikbaar."
 ],
 "Synchronized": [
  null,
  "Gesynchroniseerd"
 ],
 "Synchronized with $0": [
  null,
  "Gesynchroniseerd met $0"
 ],
 "Synchronizing": [
  null,
  "Synchroniseren"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Team": [
  null,
  "Team"
 ],
 "Team port": [
  null,
  "Teampoort"
 ],
 "Team port settings": [
  null,
  "Teampoortinstellingen"
 ],
 "Testing connection": [
  null,
  "Verbinding testen"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "De SSH-sleutel $0 van $1 op $2 zal worden toegevoegd aan het $3 bestand van $4 op $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "De SSH-sleutel $0 zal beschikbaar worden gesteld voor de rest van de sessie en zal ook beschikbaar zijn om in te loggen bij andere hosts."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "De SSH-sleutel voor inloggen op $0 is beschermd met een wachtwoord en de host staat inloggen met een wachtwoord niet toe. Geef het wachtwoord van de sleutel op $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "De SSH-sleutel voor inloggen op $0 is beschermd. Je kunt inloggen met je inlogwachtwoord of door het wachtwoord van de sleutel op te geven op $1."
 ],
 "The cockpit service is automatically included": [
  null,
  "De cockpit-service is automatisch inbegrepen"
 ],
 "The fingerprint should match:": [
  null,
  "De vingerafdruk moet overeenkomen met:"
 ],
 "The key password can not be empty": [
  null,
  "Het sleutelwachtwoord mag niet leeg zijn"
 ],
 "The key passwords do not match": [
  null,
  "De sleutelwachtwoorden komen niet overeen"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "De ingelogde gebruiker mag geen systeemwijzigingen bekijken"
 ],
 "The password can not be empty": [
  null,
  "Het wachtwoord mag niet leeg zijn"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "De resulterende vingerafdruk is prima te delen via openbare methoden, inclusief e-mail."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "De resulterende vingerafdruk kan prima worden gedeeld via openbare methoden, waaronder e-mail. Als je iemand anders vraagt om de verificatie voor je uit te voeren, kan hij of zij de resultaten op elke gewenste manier verzenden."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "De server weigerde te verifiëren met behulp van ondersteunde methoden."
 ],
 "There are no active services in this zone": [
  null,
  "Er zijn geen actieve services in deze zone"
 ],
 "This device cannot be managed here.": [
  null,
  "Dit apparaat kan hier niet beheerd worden."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Dit gereedschap configureert het SELinux-beleid en kan helpen bij het begrijpen en oplossen van beleidsschendingen."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Dit gereedschap genereert een archief met configuratie- en diagnostische informatie van het draaiende systeem. Het archief kan lokaal of centraal worden opgeslagen voor opname- of trackingsoeleinden of kan worden verzonden naar vertegenwoordigers van de technische ondersteuning, ontwikkelaars of systeembeheerders om te helpen bij het opsporen van technische fouten en het debuggen."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Dit gereedschap beheert lokale opslag, zoals bestandssystemen, LVM2-volumegroepen en NFS-koppelingen."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Dit gereedschap beheert netwerken zoals bindingen, bruggen, teams, VLAN's en firewalls met behulp van NetworkManager en Firewalld. NetworkManager is niet compatibel met Ubuntu's standaard systemd-networkd en Debian's ifupdown-scripts."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Deze zone bevat de cockpitservice. Zorg ervoor dat deze zone niet van toepassing is op je huidige webconsoleverbinding."
 ],
 "Time zone": [
  null,
  "Tijdzone"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Controleer de vingerafdruk van de hostsleutel om ervoor te zorgen dat je verbinding niet wordt onderschept door een kwaadwillende derde partij:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Om een vingerafdruk te verifiëren, voer je het volgende uit op $0 terwijl je fysiek achter de machine zit of via een vertrouwd netwerk:"
 ],
 "Toggle date picker": [
  null,
  "Datumkiezer omschakelen"
 ],
 "Too much data": [
  null,
  "Teveel data"
 ],
 "Total size: $0": [
  null,
  "Totale grootte: $0"
 ],
 "Tower": [
  null,
  "Toren"
 ],
 "Transmitting": [
  null,
  "Zenden"
 ],
 "Troubleshoot…": [
  null,
  "Problemen oplossen…"
 ],
 "Trust and add host": [
  null,
  "Vertrouw en voeg host toe"
 ],
 "Trust level": [
  null,
  "Vertrouwensniveau"
 ],
 "Trying to synchronize with $0": [
  null,
  "Bezig met synchroniseren met $0"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Kan niet inloggen op $0. De host accepteert geen aanmelden met wachtwoord of een van je SSH-sleutels."
 ],
 "Unexpected error": [
  null,
  "Onverwachte fout"
 ],
 "Unknown": [
  null,
  "Onbekend"
 ],
 "Unknown \"$0\"": [
  null,
  "Onbekend \"$0\""
 ],
 "Unknown configuration": [
  null,
  "Onbekende configuratie"
 ],
 "Unknown host: $0": [
  null,
  "Onbekende host: $0"
 ],
 "Unknown service name": [
  null,
  "Onbekende servicenaam"
 ],
 "Unmanaged interfaces": [
  null,
  "Onbeheerde interfaces"
 ],
 "Untrusted host": [
  null,
  "Niet vertrouwde host"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "VLAN-ID"
 ],
 "Verify fingerprint": [
  null,
  "Vingerafdruk verifiëren"
 ],
 "View all logs": [
  null,
  "Bekijk alle logboeken"
 ],
 "View automation script": [
  null,
  "Bekijk automatiseringsscript"
 ],
 "Visit firewall": [
  null,
  "Bezoek firewall"
 ],
 "Waiting": [
  null,
  "Aan het wachten"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Wachten tot andere softwarebeheerhandelingen voltooid zijn"
 ],
 "Weak password": [
  null,
  "Zwak wachtwoord"
 ],
 "Web Console for Linux servers": [
  null,
  "Webconsole voor Linux-servers"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Wordt ingesteld op \"Automatisch\""
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "Ja"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Je maakt voor de eerste keer verbinding met $0."
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Jr bent niet bevoegd om de firewall te wijzigen."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Je browser staat plakken vanuit het contextmenu niet toe. Je kunt Shift+Insert gebruiken."
 ],
 "Your session has been terminated.": [
  null,
  "Je sessie is beëindigd."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Je sessie is verlopen. Log nogmaals in."
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "[binary data]": [
  null,
  "[binaire data]"
 ],
 "[no data]": [
  null,
  "[geen data]"
 ],
 "edit": [
  null,
  "bewerken"
 ],
 "in less than a minute": [
  null,
  "in minder dan een minuut"
 ],
 "less than a minute ago": [
  null,
  "minder dan een minuut geleden"
 ],
 "password quality": [
  null,
  "wachtwoordkwaliteit"
 ],
 "show less": [
  null,
  "toon minder"
 ],
 "show more": [
  null,
  "toon meer"
 ],
 "wireguard-tools package is not installed": [
  null,
  "Pakket wireguard-tools is niet geïnstalleerd"
 ]
});
