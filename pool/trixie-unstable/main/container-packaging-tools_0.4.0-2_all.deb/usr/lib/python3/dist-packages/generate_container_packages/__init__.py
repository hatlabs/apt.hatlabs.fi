"""Container Packaging Tools - Generate Debian packages from container app definitions."""

__version__ = "0.4.0"
__author__ = "Hat Labs"
__license__ = "MIT"
