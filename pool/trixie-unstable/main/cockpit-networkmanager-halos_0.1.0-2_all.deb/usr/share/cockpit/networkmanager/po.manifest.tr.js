cockpit.locale({
 "": {
  "plural-forms": (n) => (n>1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "Kernel dump": [
  null,
  "Çekirdek dökümü"
 ],
 "Managing VLANs": [
  null,
  "VLAN'ları yönetme"
 ],
 "Managing firewall": [
  null,
  "Güvenlik duvarını yönetme"
 ],
 "Managing networking bonds": [
  null,
  "Ağ birleştirmelerini yönetme"
 ],
 "Managing networking bridges": [
  null,
  "Ağ köprülerini yönetme"
 ],
 "Managing networking teams": [
  null,
  "Ağ takımlarını yönetme"
 ],
 "Networking": [
  null,
  "Ağ"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Hizmetler"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "bond": [
  null,
  "birleştirme"
 ],
 "bridge": [
  null,
  "köprü"
 ],
 "firewall": [
  null,
  "güvenlik duvarı"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "arayüz"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "ağ"
 ],
 "port": [
  null,
  "bağlantı noktası"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "takım"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "bölge"
 ]
});
