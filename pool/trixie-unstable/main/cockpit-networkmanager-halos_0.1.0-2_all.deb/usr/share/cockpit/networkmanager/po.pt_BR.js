cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 active zone": [
  null,
  "$0 zona ativa",
  "$0 zonas ativas"
 ],
 "$0 day": [
  null,
  "$0 dia",
  "$0 dias"
 ],
 "$0 exited with code $1": [
  null,
  "$0 foi encerrado com o código $1"
 ],
 "$0 failed": [
  null,
  "$0 falhou"
 ],
 "$0 hour": [
  null,
  "$0 hora",
  "$0 horas"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 não está disponível em nenhum repositório."
 ],
 "$0 key changed": [
  null,
  "$0 chave alterada"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 morto com sinal $1"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minutos"
 ],
 "$0 month": [
  null,
  "$0 mês",
  "$0 meses"
 ],
 "$0 week": [
  null,
  "$0 semana",
  "$0 semanas"
 ],
 "$0 will be installed.": [
  null,
  "$0 será instalado."
 ],
 "$0 year": [
  null,
  "$0 ano",
  "$0 anos"
 ],
 "$0 zone": [
  null,
  "Zona $0"
 ],
 "1 day": [
  null,
  "1 dia"
 ],
 "1 hour": [
  null,
  "1 hora"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "1 week": [
  null,
  "1 semana"
 ],
 "20 minutes": [
  null,
  "20 minutos"
 ],
 "40 minutes": [
  null,
  "40 minutos"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "6 hours": [
  null,
  "6 horas"
 ],
 "60 minutes": [
  null,
  "60 minutos"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Uma versão compatível do Cockpit não está instalada em $0."
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Uma ligação de rede combina várias interfaces de rede em uma interface lógica com maior taxa de transferência ou redundância."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Uma nova chave SSH em $0 será criada por $1 em $2 e será adicionada ao arquivo $3 de $4 em $5."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "Monitoramento ARP"
 ],
 "ARP ping": [
  null,
  "Ping ARP"
 ],
 "Absent": [
  null,
  "Ausente"
 ],
 "Acceptable password": [
  null,
  "Senha aceitável"
 ],
 "Actions": [
  null,
  "Ações"
 ],
 "Active": [
  null,
  "Ativo"
 ],
 "Active backup": [
  null,
  "Backup ativo"
 ],
 "Adaptive load balancing": [
  null,
  "Balanceamento de carga dinâmico"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Transmissão dinâmica de balanceamento de carga"
 ],
 "Add": [
  null,
  "Adicionar"
 ],
 "Add $0": [
  null,
  "Adicionar $0"
 ],
 "Add DNS server": [
  null,
  "Adicionar servidor DNS"
 ],
 "Add VLAN": [
  null,
  "Adicionar VLAN"
 ],
 "Add VPN": [
  null,
  "Adicionar VPN"
 ],
 "Add WireGuard VPN": [
  null,
  "Adicionar WireGuard VPN"
 ],
 "Add a new zone": [
  null,
  "Adicionar uma nova zona"
 ],
 "Add address": [
  null,
  "Adicionar endereço"
 ],
 "Add bond": [
  null,
  "Adicionar vínculo"
 ],
 "Add bridge": [
  null,
  "Adicionar ponte"
 ],
 "Add member": [
  null,
  "Adicionar membro"
 ],
 "Add new zone": [
  null,
  "Adicionar nova zona"
 ],
 "Add peer": [
  null,
  "Adicionar par"
 ],
 "Add ports": [
  null,
  "Adicionar portas"
 ],
 "Add ports to $0 zone": [
  null,
  "Adicionar portas para zona $0"
 ],
 "Add route": [
  null,
  "Adicionar rota"
 ],
 "Add search domain": [
  null,
  "Adicionar busca de domínios"
 ],
 "Add services": [
  null,
  "Adicionar serviços"
 ],
 "Add services to $0 zone": [
  null,
  "Adicionar serviços à zona $0"
 ],
 "Add services to zone $0": [
  null,
  "Adicionar serviços à zona $0"
 ],
 "Add team": [
  null,
  "Adicionar equipe"
 ],
 "Add zone": [
  null,
  "Adicionar zona"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Adicionar $0 irá interromper a conexão com o servidor e tornará a interface de administração indisponível."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Adicionar portas personalizadas recarregará o firewalld. Uma recarga resultará na perda de qualquer configuração somente em tempo de execução!"
 ],
 "Additional DNS $val": [
  null,
  "DNS adicional $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Domínios de pesquisa de DNS adicionais $val"
 ],
 "Additional address $val": [
  null,
  "Endereço adicional $val"
 ],
 "Additional packages:": [
  null,
  "Pacotes adicionais:"
 ],
 "Additional ports": [
  null,
  "Portas adicionais"
 ],
 "Address": [
  null,
  "Endereço"
 ],
 "Address $val": [
  null,
  "Endereço $val"
 ],
 "Addresses": [
  null,
  "Endereços"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Os endereços não estão formatados corretamente"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administração com o Console Web do Cockpit"
 ],
 "Advanced TCA": [
  null,
  "TCA avançado"
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "Allowed IPs": [
  null,
  "IPs permitidos"
 ],
 "Allowed addresses": [
  null,
  "Endereços permitidos"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentação de papéis do Ansible"
 ],
 "Authenticating": [
  null,
  "Autenticando"
 ],
 "Authentication": [
  null,
  "Autenticação"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autenticação é necessária para executar ações privilegiadas no Console Web do Cockpit"
 ],
 "Authorize SSH key": [
  null,
  "Autorizar chave SSH"
 ],
 "Automatic": [
  null,
  "Automático"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automático (apenas DHCP)"
 ],
 "Automatically using NTP": [
  null,
  "Usando automaticamente o NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Usando automaticamente servidores NTP adicionais"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Usando automaticamente servidores NTP específicos"
 ],
 "Automation script": [
  null,
  "Script de automação"
 ],
 "Balancer": [
  null,
  "Balanceador"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Invólucro da lâmina"
 ],
 "Bond": [
  null,
  "Bond"
 ],
 "Bridge": [
  null,
  "Ponte"
 ],
 "Bridge port": [
  null,
  "Bridge porta"
 ],
 "Bridge port settings": [
  null,
  "Configurações da Porta de Ponte"
 ],
 "Broadcast": [
  null,
  "Broadcast"
 ],
 "Broken configuration": [
  null,
  "Configuração quebrada"
 ],
 "Bus expansion chassis": [
  null,
  "Chassi de Expansão de Barramento"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Cannot forward login credentials": [
  null,
  "Não é possível prosseguir com as credenciais de login"
 ],
 "Cannot schedule event in the past": [
  null,
  "Não é possível agendar eventos no passado"
 ],
 "Carrier": [
  null,
  "Sinal"
 ],
 "Change": [
  null,
  "Alterar"
 ],
 "Change system time": [
  null,
  "Alterar Horário do Sistema"
 ],
 "Change the settings": [
  null,
  "Alterar as configurações"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "As chaves alteradas frequentemente são resultado de uma reinstalação do sistema operacional. No entanto, uma alteração inesperada pode indicar uma tentativa de terceiros de interceptar sua conexão."
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Alterar as configurações irá encerrar a conexão com o servidor, e tornará a administração interface do usuário indisponível."
 ],
 "Checking IP": [
  null,
  "Checando IP"
 ],
 "Checking installed software": [
  null,
  "Verificando o software instalado"
 ],
 "Clear input value": [
  null,
  "Limpar valor inserido"
 ],
 "Close": [
  null,
  "Fechar"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuração do cockpit do NetworkManager e Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "O Cockpit não poderia entrar em contato com o host fornecido."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit é um gerenciador de Servidores que facilita a tarefa de administrar seu servidor Linux via navegador web. Alternar entre o terminal e a ferramenta web, não é dif[icil. Um serviço pode ser iniciado pelo Cockpit e finalizado pelo Terminal. Da mesma forma, se um erro ocorrer no terminal, este pode ser detectado via interface do Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "O Cockpit não é compatível com o software no sistema."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit não está instalado"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit não está instalado no sistema."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit é perfeito para novos administradores de sistemas, permitindo-lhes facilmente realizar tarefas simples, como a administração de armazenamento, inspecionando logs e iniciar/parar serviços. É possível monitorar e administrar vários servidores ao mesmo tempo. Basta adicioná-los com um único clique e suas máquinas vão cuidar de seus companheiros."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Coletar e empacotar dados de diagnóstico e suporte"
 ],
 "Collect kernel crash dumps": [
  null,
  "Coletar despejos de travamento de kernel"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "São aceitos portas, intervalos e serviços separados por vírgula"
 ],
 "Compact PCI": [
  null,
  "Compacto PCI"
 ],
 "Configuring": [
  null,
  "Configurando"
 ],
 "Configuring IP": [
  null,
  "Configurando IP"
 ],
 "Confirm key password": [
  null,
  "Confirme a senha da chave"
 ],
 "Confirm removal of $0": [
  null,
  "Confirmar remoção de $0"
 ],
 "Connect automatically": [
  null,
  "Conecte automaticamente"
 ],
 "Connection has timed out.": [
  null,
  "A conexão expirou."
 ],
 "Connection will be lost": [
  null,
  "A conexão será perdida"
 ],
 "Convertible": [
  null,
  "Conversível"
 ],
 "Copied": [
  null,
  "Copiado"
 ],
 "Copy": [
  null,
  "Copiar"
 ],
 "Copy to clipboard": [
  null,
  "Copiar para área de transferência"
 ],
 "Create $0": [
  null,
  "Criar $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Criar uma nova chave SSH e autorizá-la"
 ],
 "Create it": [
  null,
  "Criá-lo"
 ],
 "Create new task file with this content.": [
  null,
  "Crie um novo arquivo de tarefa com esse conteúdo."
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Criar esse $0 quebrará a conexão com o servidor e tornará a interface de administração indisponível."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Custom ports": [
  null,
  "Portas customizadas"
 ],
 "Custom zones": [
  null,
  "Zonas customizadas"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "DNS Busca de Domínios"
 ],
 "DNS search domains $val": [
  null,
  "Domínios de Pesquisa DNS $val"
 ],
 "Deactivating": [
  null,
  "Desativando"
 ],
 "Delay": [
  null,
  "Atraso"
 ],
 "Delete": [
  null,
  "Excluir"
 ],
 "Delete $0": [
  null,
  "Deletar $0"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Excluindo $0 a conexão com o servidor será encerrada, e tornará a administração da interface do usuário indisponível."
 ],
 "Description": [
  null,
  "Descrição"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Destacável"
 ],
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Disable the firewall": [
  null,
  "Desabilitar o firewall"
 ],
 "Disabled": [
  null,
  "Desabilitado"
 ],
 "Docking station": [
  null,
  "Estação de ancoragem"
 ],
 "Downloading $0": [
  null,
  "Baixando $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Edit": [
  null,
  "Editar"
 ],
 "Edit VLAN settings": [
  null,
  "Editar configurações VLAN"
 ],
 "Edit WireGuard VPN": [
  null,
  "Editar VPN WireGuard"
 ],
 "Edit bond settings": [
  null,
  "Editar configurações de ligação"
 ],
 "Edit bridge settings": [
  null,
  "Editar configurações de ponte"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Editar serviços customizado para zona $0"
 ],
 "Edit rules and zones": [
  null,
  "Editar regras e zonas"
 ],
 "Edit service": [
  null,
  "Editar Serviço"
 ],
 "Edit service $0": [
  null,
  "Editar serviço $0"
 ],
 "Edit team settings": [
  null,
  "Editar configurações da Equipe"
 ],
 "Embedded PC": [
  null,
  "PC integrado"
 ],
 "Enable or disable the device": [
  null,
  "Habilitar ou desabilitar o dispositivo"
 ],
 "Enable service": [
  null,
  "Ativar serviço"
 ],
 "Enable the firewall": [
  null,
  "Habilitar o firewall"
 ],
 "Enabled": [
  null,
  "Habilitado"
 ],
 "Endpoint": [
  null,
  "Destino"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "O endpoint que atua como um \"servidor\" precisa ser especificado como host:porta, caso contrário, pode ser deixado em branco."
 ],
 "Enter a valid MAC address": [
  null,
  "Insira um endereço MAC válido"
 ],
 "Entire subnet": [
  null,
  "Toda a sub-rede"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet MTU"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Exemplo: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Exemplo: 88,2019,nfs,rsync"
 ],
 "Excellent password": [
  null,
  "Senha excelente"
 ],
 "Expansion chassis": [
  null,
  "Chassi de Expansão"
 ],
 "Failed": [
  null,
  "Falhou"
 ],
 "Failed to add port": [
  null,
  "Falha ao adicionar porta"
 ],
 "Failed to add service": [
  null,
  "Falha ao adicionar serviço"
 ],
 "Failed to add zone": [
  null,
  "Falha ao adicionar zona"
 ],
 "Failed to change password": [
  null,
  "Falha ao mudar senha"
 ],
 "Failed to edit service": [
  null,
  "Falha ao editar serviço"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Falha ao habilitar $0 no firewalld"
 ],
 "Failed to save settings": [
  null,
  "Falha ao salvar as configurações"
 ],
 "Filter services": [
  null,
  "Serviços de filtro"
 ],
 "Firewall": [
  null,
  "Firewall"
 ],
 "Firewall is not available": [
  null,
  "Firewall não está disponível"
 ],
 "Forward delay $forward_delay": [
  null,
  "Encaminhado Atraso $forward_delay"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "General": [
  null,
  "Geral"
 ],
 "Generated": [
  null,
  "Gerado"
 ],
 "Go to now": [
  null,
  "Ir para agora"
 ],
 "Group": [
  null,
  "Grupo"
 ],
 "Hair pin mode": [
  null,
  "Modo Hair pin"
 ],
 "Hairpin mode": [
  null,
  "Modo Hairpin"
 ],
 "Handheld": [
  null,
  "Dispositivo portátil"
 ],
 "Hello time $hello_time": [
  null,
  "Tempo de hello $hello_time"
 ],
 "Hide confirmation password": [
  null,
  "Ocultar confirmação da senha"
 ],
 "Hide password": [
  null,
  "Ocultar senha"
 ],
 "Host key is incorrect": [
  null,
  "Chave de Host incorreta"
 ],
 "ID": [
  null,
  "ID"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "IP address": [
  null,
  "Endereço IP"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "Endereço IP com prefixo de roteamento. Separe múltiplos valores com uma vírgula. Exemplo: 192.0.2.0/24, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 settings": [
  null,
  "IPv4 Ajustes"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "IPv6 Ajustes"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Se deixado em branco, o ID será gerado com base nos serviços de porta e números de porta associados"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Se a impressão digital corresponder, clique em \"Confiar e adicionar host\". Caso contrário, não se conecte e entre em contato com o administrador."
 ],
 "Ignore": [
  null,
  "Ignorar"
 ],
 "Inactive": [
  null,
  "Inativo"
 ],
 "Included services": [
  null,
  "Serviços inclusos"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "As solicitações de entrada são bloqueadas por padrão. As solicitações de saída não são bloqueadas."
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Install software": [
  null,
  "Instalar o software"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "Interface": [
  null,
  "Interface",
  "Interfaces"
 ],
 "Interface members": [
  null,
  "Membros da interface"
 ],
 "Interfaces": [
  null,
  "Interfaces"
 ],
 "Internal error": [
  null,
  "Erro interno"
 ],
 "Invalid address $0": [
  null,
  "Endereço inválido $0"
 ],
 "Invalid date format": [
  null,
  "Formato de data inválido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato de data inválido e formato de tempo inválido"
 ],
 "Invalid file permissions": [
  null,
  "Permissão de arquivos inválida"
 ],
 "Invalid metric $0": [
  null,
  "Métrica inválida $0"
 ],
 "Invalid port number": [
  null,
  "Número de porta inválido"
 ],
 "Invalid prefix $0": [
  null,
  "Prefixo inválido $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Prefixo ou máscara de rede inválidos $0"
 ],
 "Invalid range": [
  null,
  "Intervalo inválido"
 ],
 "Invalid time format": [
  null,
  "Formato de tempo inválido"
 ],
 "Invalid timezone": [
  null,
  "Fuso horário inválido"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Keep connection": [
  null,
  "Manter conexão"
 ],
 "Kernel dump": [
  null,
  "Dump do kernel"
 ],
 "Key password": [
  null,
  "Senha da chave"
 ],
 "LACP key": [
  null,
  "Chave LACP"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Learn more": [
  null,
  "Saiba mais"
 ],
 "Link down delay": [
  null,
  "Link down atraso"
 ],
 "Link local": [
  null,
  "Link Local"
 ],
 "Link monitoring": [
  null,
  "Monitoramento de Link"
 ],
 "Link up delay": [
  null,
  "Link up atraso"
 ],
 "Link watch": [
  null,
  "Link para assistir"
 ],
 "Listen port": [
  null,
  "Porta de escuta"
 ],
 "Listen port must be a number": [
  null,
  "A porta de escuta deve ser um número"
 ],
 "Load balancing": [
  null,
  "Balanceamento de Carga"
 ],
 "Loading system modifications...": [
  null,
  "Carregando modificações do sistema..."
 ],
 "Log in": [
  null,
  "Entrar"
 ],
 "Log in to $0": [
  null,
  "Iniciar sessão para $0"
 ],
 "Log messages": [
  null,
  "Mensagens de Log"
 ],
 "Login failed": [
  null,
  "Falha ao logar"
 ],
 "Low profile desktop": [
  null,
  "Desktop de baixo perfil"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (Recomendado)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "O MTU deve ser um número positivo"
 ],
 "Main server chassis": [
  null,
  "Chassi do Servidor Principal"
 ],
 "Manage storage": [
  null,
  "Gerenciar armazenamento"
 ],
 "Managed interfaces": [
  null,
  "Interfaces Gerenciadas"
 ],
 "Manual": [
  null,
  "Manual"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Maximum message age $max_age": [
  null,
  "Máxima permanência da mensagem $max_age"
 ],
 "Message to logged in users": [
  null,
  "Mensagem para usuários logados"
 ],
 "Metric": [
  null,
  "Métricas"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini torre"
 ],
 "Mode": [
  null,
  "Modo"
 ],
 "Monitoring interval": [
  null,
  "Monitorando intervalo"
 ],
 "Monitoring targets": [
  null,
  "Alvos de monitoramento"
 ],
 "Multi-system chassis": [
  null,
  "Chassi Multi-sistema"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  ""
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "NTP server": [
  null,
  "Servidor NTP"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Need at least one NTP server": [
  null,
  "Precisa de pelo menos um servidor NTP"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Dispositivos de rede e gráficos requerem o NetworkManager"
 ],
 "Network logs": [
  null,
  "Logs de rede"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager não está instalado"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager não está em execução"
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "New password was not accepted": [
  null,
  "Nova senha não foi aceita"
 ],
 "No": [
  null,
  "Não"
 ],
 "No carrier": [
  null,
  "Sem sinal"
 ],
 "No delay": [
  null,
  "Sem Atraso"
 ],
 "No description available": [
  null,
  "Sem descrição disponível"
 ],
 "No peers added.": [
  null,
  "Nenhum par adicionado."
 ],
 "No results found": [
  null,
  "Nenhum resultado encontrado"
 ],
 "No such file or directory": [
  null,
  "Diretório ou arquivo não encontrado"
 ],
 "No system modifications": [
  null,
  "Nenhuma modificações no sistema"
 ],
 "None": [
  null,
  "Nenhum"
 ],
 "Not a valid private key": [
  null,
  "Chave privada não válida"
 ],
 "Not authorized to disable the firewall": [
  null,
  ""
 ],
 "Not authorized to enable the firewall": [
  null,
  ""
 ],
 "Not available": [
  null,
  "Indisponível"
 ],
 "Not permitted to configure network devices": [
  null,
  "Não autorizado a configurar dispositivos de rede"
 ],
 "Not permitted to perform this action.": [
  null,
  "Não é permitido executar esta ação."
 ],
 "Not synchronized": [
  null,
  "Não sincronizado"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Senha antiga não aceita"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Uma vez instalado o Cockpit, habilite-o com \"systemctl enable --now cockpit.socket\"."
 ],
 "Options": [
  null,
  "Opções"
 ],
 "Other": [
  null,
  "De outros"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit caiu"
 ],
 "Parent": [
  null,
  "Parente"
 ],
 "Parent $parent": [
  null,
  "Pai $parent"
 ],
 "Part of $0": [
  null,
  "Parte of $0"
 ],
 "Passive": [
  null,
  "Passivo"
 ],
 "Password": [
  null,
  "Senha"
 ],
 "Password is not acceptable": [
  null,
  "Senha não é aceitavél"
 ],
 "Password is too weak": [
  null,
  "Senha é muito fraca"
 ],
 "Password not accepted": [
  null,
  "Senha não aceita"
 ],
 "Paste": [
  null,
  "Colar"
 ],
 "Path cost": [
  null,
  "Custo do Caminho"
 ],
 "Path cost $path_cost": [
  null,
  "Custo do caminho $path_cost"
 ],
 "Path to file": [
  null,
  "Caminho para o arquivo"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  ""
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820, [2001:db8::1]:51820 or example.com:51820": [
  null,
  ""
 ],
 "Peers": [
  null,
  ""
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  ""
 ],
 "Peripheral chassis": [
  null,
  "Chassi Periférico"
 ],
 "Permanent": [
  null,
  "Permanente"
 ],
 "Pick date": [
  null,
  ""
 ],
 "Ping interval": [
  null,
  "Intervalo de Ping"
 ],
 "Ping target": [
  null,
  "Alvo do Ping"
 ],
 "Pizza box": [
  null,
  "Servidor compacto"
 ],
 "Please install the $0 package": [
  null,
  "Por favor, instale o pacote de $0"
 ],
 "Portable": [
  null,
  "Portatil"
 ],
 "Ports": [
  null,
  "Portas"
 ],
 "Prefix length": [
  null,
  "Comprimento do prefixo"
 ],
 "Prefix length or netmask": [
  null,
  "Comprimento do prefixo ou máscara de rede"
 ],
 "Preparing": [
  null,
  "Preparando"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Preserve": [
  null,
  "Preservar"
 ],
 "Primary": [
  null,
  "Primário"
 ],
 "Priority": [
  null,
  "Prioridade"
 ],
 "Priority $priority": [
  null,
  "Prioridade $priority"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "A solicitação via ssh-add expirou"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Solicitação via ssh-keygen expirou"
 ],
 "Public key": [
  null,
  "Chave Pública"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  ""
 ],
 "RAID chassis": [
  null,
  "Chassis do RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chassis de montagem do Rack"
 ],
 "Random": [
  null,
  "Aleatório(a)"
 ],
 "Range": [
  null,
  "Intervalo"
 ],
 "Range must be strictly ordered": [
  null,
  "O intervalo deve ser estritamente ordenado"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Receiving": [
  null,
  "Recebendo"
 ],
 "Removals:": [
  null,
  "Remoções:"
 ],
 "Remove $0": [
  null,
  "Remover $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  ""
 ],
 "Remove item": [
  null,
  "Remover item"
 ],
 "Remove service $0": [
  null,
  "Remover serviço $0"
 ],
 "Remove zone $0": [
  null,
  "Remover zona $0"
 ],
 "Removing $0": [
  null,
  "Removendo $0"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Removendo $0 irá encerrar a conexão com o servidor e tornará a administração da interface do usuário indisponível."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  ""
 ],
 "Removing the zone will remove all services within it.": [
  null,
  ""
 ],
 "Restoring connection": [
  null,
  "Restaurando conexão"
 ],
 "Round robin": [
  null,
  "Round robin"
 ],
 "Routes": [
  null,
  "Rotas"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "Runner": [
  null,
  "Executor"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Chave SSH"
 ],
 "STP forward delay": [
  null,
  "STP Atraso de Redirecionamento"
 ],
 "STP hello time": [
  null,
  "Tempo de saudação STP"
 ],
 "STP maximum message age": [
  null,
  "STP Máxima permanência de mensagem"
 ],
 "STP priority": [
  null,
  "STP Prioridade"
 ],
 "Save": [
  null,
  "Salvar"
 ],
 "Sealed-case PC": [
  null,
  "PC com caixa vedada"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  ""
 ],
 "Sending": [
  null,
  "Enviando"
 ],
 "Server": [
  null,
  "Servidor"
 ],
 "Server has closed the connection.": [
  null,
  "O servidor encerrou a conexão."
 ],
 "Service": [
  null,
  "Serviço"
 ],
 "Services": [
  null,
  "Serviços"
 ],
 "Set time": [
  null,
  "Definir Tempo"
 ],
 "Set to": [
  null,
  "Configurado para"
 ],
 "Shared": [
  null,
  "Compartilhado"
 ],
 "Shell script": [
  null,
  "Shell script"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show password": [
  null,
  "Exibir senha"
 ],
 "Shut down": [
  null,
  "Encerrar"
 ],
 "Single rank": [
  null,
  ""
 ],
 "Sorted from least to most trusted": [
  null,
  ""
 ],
 "Space-saving computer": [
  null,
  "Computador com economia de espaço"
 ],
 "Spanning tree protocol": [
  null,
  "Protocolo Spanning tree"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Protocolo Spanning tree (STP)"
 ],
 "Specific time": [
  null,
  "Tempo Específico"
 ],
 "Stable": [
  null,
  "Estável"
 ],
 "Start service": [
  null,
  "Começar serviço"
 ],
 "Status": [
  null,
  "Estado"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Sticky": [
  null,
  "Persistente"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Sub-Chassis": [
  null,
  "Sub chassis"
 ],
 "Sub-Notebook": [
  null,
  "Sub notebook"
 ],
 "Switch off $0": [
  null,
  "Desligar $0"
 ],
 "Switch on $0": [
  null,
  "Ligar $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Desligando $0 irá encerrar a conexão com o servidor, e tornará a administração da interface do usuário indisponível."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Ligando $0 irá encerrar a conexão com o servidor e tornará a administração da interface do usuário indisponível."
 ],
 "Synchronized": [
  null,
  "Sincronizado"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizado com $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizando"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Team": [
  null,
  "Equipe"
 ],
 "Team port": [
  null,
  "Porta da Equipe"
 ],
 "Team port settings": [
  null,
  "Configurações da Porta da Equipe"
 ],
 "Testing connection": [
  null,
  "Testando conexão"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  ""
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  ""
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  ""
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  ""
 ],
 "The cockpit service is automatically included": [
  null,
  ""
 ],
 "The fingerprint should match:": [
  null,
  "A impressão digital deve corresponder a:"
 ],
 "The key password can not be empty": [
  null,
  "A senha da chave não pode estar vazia"
 ],
 "The key passwords do not match": [
  null,
  "As senhas da chave não coincidem"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  ""
 ],
 "The password can not be empty": [
  null,
  "A senha não pode estar vazia"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "A impressão digital resultante pode ser compartilhada por métodos públicos, incluindo e-mail."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "A impressão digital resultante pode ser compartilhada por métodos públicos, incluindo e-mail. Se você estiver pedindo para outra pessoa fazer a verificação para você, ela pode enviar os resultados usando qualquer método."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "O servidor se recusou a autenticar usando quaisquer métodos suportados."
 ],
 "There are no active services in this zone": [
  null,
  "Não existem serviços ativos nesta zona"
 ],
 "This device cannot be managed here.": [
  null,
  "Este dispositivo não pode ser gerenciado aqui."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Esta ferramenta configura a política do SELinux e pode ajudar a entender e resolver violações de política."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Esta ferramenta configura o sistema para escrever kernel crash dumps. Ela suporta os alvos de dump \"local\" (disco), \"ssh\" e \"nfs\"."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Esta ferramenta gera um arquivo de informações de configuração e diagnóstico do sistema em execução. O arquivo pode ser armazenado localmente ou centralmente para fins de registro ou rastreamento ou pode ser enviado a representantes de suporte técnico, desenvolvedores ou administradores de sistema para auxiliar na detecção de falhas técnicas e depuração."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Esta ferramenta gerencia armazenamento local, como sistemas de arquivos, grupos de volumes LVM2 e montagens NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Esta ferramenta gerencia redes como vínculos, pontes, times, VLANs e firewalls usando NetworkManager e Firewalld. O NetworkManager é incompatível com o systemd-networkd padrão do Ubuntu e os scripts ifupdown do Debian."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Esta zona contém o serviço cockpit. Certifique-se de que esta zona não se aplique à sua conexão atual do console web."
 ],
 "Time zone": [
  null,
  "Fuso Horário"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Para garantir que sua conexão não seja interceptada por terceiros mal-intencionados, verifique a impressão digital da chave do host:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Para verificar uma impressão digital, execute o seguinte em $0 enquanto estiver fisicamente sentado na máquina ou por meio de uma rede confiável:"
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Too much data": [
  null,
  "Muitos dados"
 ],
 "Total size: $0": [
  null,
  "Tamanho total: $0"
 ],
 "Tower": [
  null,
  "Torre"
 ],
 "Troubleshoot…": [
  null,
  "Solução de problemas…"
 ],
 "Trust and add host": [
  null,
  "Confiar e adicionar host"
 ],
 "Trust level": [
  null,
  ""
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentando sincronizar com $0"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  ""
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  ""
 ],
 "Unexpected error": [
  null,
  "Erro inesperado"
 ],
 "Unknown": [
  null,
  "Desconhecido"
 ],
 "Unknown \"$0\"": [
  null,
  "Desconhecido \"$0\""
 ],
 "Unknown configuration": [
  null,
  "Configuração desconhecida"
 ],
 "Unknown host: $0": [
  null,
  "Host desconhecido: $0"
 ],
 "Unknown service name": [
  null,
  "Nome de serviço desconhecido"
 ],
 "Unmanaged interfaces": [
  null,
  "Interfaces Não Gerenciadas"
 ],
 "Untrusted host": [
  null,
  "Host não confiável"
 ],
 "Use $0": [
  null,
  "Usar $0"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "ID da VLAN"
 ],
 "Verify fingerprint": [
  null,
  "Verificar digital"
 ],
 "View all logs": [
  null,
  "Ver todos os logs"
 ],
 "View automation script": [
  null,
  ""
 ],
 "Waiting": [
  null,
  "Aguardando"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Aguardando que outras operações de gerenciamento de software terminem"
 ],
 "Web Console for Linux servers": [
  null,
  "Console da Web para servidores Linux"
 ],
 "Will be set to \"Automatic\"": [
  null,
  ""
 ],
 "WireGuard": [
  null,
  ""
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "Sim"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  ""
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Você não está autorizado a modificar o firewall."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  ""
 ],
 "Your session has been terminated.": [
  null,
  "Sua sessão foi encerrada."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sua sessão expirou. Por favor, faça o login novamente."
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "[binary data]": [
  null,
  "[dados binários]"
 ],
 "[no data]": [
  null,
  "[sem dados]"
 ],
 "edit": [
  null,
  "editar"
 ],
 "in less than a minute": [
  null,
  "em menos de um minuto"
 ],
 "less than a minute ago": [
  null,
  "menos de um minuto atrás"
 ],
 "password quality": [
  null,
  "qualidade da senha"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar mais"
 ],
 "wireguard-tools package is not installed": [
  null,
  "O pacote wireguard-tools não está instalado"
 ]
});
