cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Kernel dump": [
  null,
  "Dump do kernel"
 ],
 "Managing VLANs": [
  null,
  "Gerenciando VLANs"
 ],
 "Managing firewall": [
  null,
  "Gerenciando firewall"
 ],
 "Managing networking bonds": [
  null,
  "Gerenciando vínculos de rede"
 ],
 "Managing networking bridges": [
  null,
  "Gerenciando pontes de rede"
 ],
 "Managing networking teams": [
  null,
  "Gerenciando uniões de rede"
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Serviços"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "bond": [
  null,
  ""
 ],
 "bridge": [
  null,
  "ponte"
 ],
 "firewall": [
  null,
  "firewall"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "interface"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "rede"
 ],
 "port": [
  null,
  "porta"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "equipe"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "zona"
 ]
});
