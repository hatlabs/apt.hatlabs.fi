cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "ru",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Диагностические отчёты"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Managing VLANs": [
  null,
  "Управление VLAN"
 ],
 "Managing firewall": [
  null,
  "Управление межсетевым экраном"
 ],
 "Managing networking bonds": [
  null,
  "Управление сетевыми объединениями"
 ],
 "Managing networking bridges": [
  null,
  "Управление сетевыми мостами"
 ],
 "Managing networking teams": [
  null,
  "Управление сетевыми сопряжениями"
 ],
 "Networking": [
  null,
  "Сеть"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Службы"
 ],
 "Storage": [
  null,
  "Хранилище"
 ],
 "bond": [
  null,
  "привязка"
 ],
 "bridge": [
  null,
  "мост"
 ],
 "firewall": [
  null,
  "Межсетевой экран"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "интерфейс"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "сеть"
 ],
 "port": [
  null,
  "порт"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "команда"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "зона"
 ]
});
